## =====================================================================
## Section 7.6: Bayesian false discovery rate for the direction of the trends
## (Muller, Parmigiani, Robert and Rousseau, 2004)
##
## At each cell, p = Pr(increase | data). We declare an increase where p is
## large and a decrease where 1 - p is large, taking the cells in decreasing
## order of max(p, 1 - p) as long as the average posterior probability of the
## opposite direction among the declared cells stays below alpha.
## Input: results/app_results.csv, data/jjas_long.csv (same 25% exclusion as
## scripts/12_application_summarize.R). Output: console; figures/app_fdr.pdf (optional map)
## Run: Rscript scripts/13_application_fdr.R
## =====================================================================

alpha    <- 0.05
zero_max <- 0.25

r <- read.csv("results/app_results.csv"); r <- r[!duplicated(r$cell), ]
dat <- read.csv("data/jjas_long.csv")
nz <- aggregate(y ~ lon + lat, dat, function(z) mean(z == 0))
names(nz)[3] <- "frac_zero"
r <- merge(r, nz, by = c("lon", "lat")); r <- r[r$frac_zero <= zero_max, ]
cat("Cells analyzed:", nrow(r), "\n")

bfdr <- function(p, alpha) {
  q <- pmax(p, 1 - p)                      # posterior probability of the more likely direction
  o <- order(q, decreasing = TRUE)
  fdr <- cumsum(1 - q[o]) / seq_along(o)   # expected FDR when declaring the first k cells
  k <- max(c(0, which(fdr <= alpha)))
  declared <- rep(FALSE, length(p)); if (k > 0) declared[o[1:k]] <- TRUE
  list(declared = declared, threshold = if (k > 0) q[o[k]] else NA, k = k)
}

for (per in c("1901-2025")) {
  b <- bfdr(r$pr_increase_st, alpha)
  inc <- b$declared & r$pr_increase_st > 0.5; dec <- b$declared & r$pr_increase_st < 0.5
  cat(sprintf("\n%s, Bayesian FDR %.2f: threshold on Pr(direction | data) = %.3f\n", per, alpha, b$threshold))
  cat(sprintf("Declared: %d cells (%.3f); increases %.3f, decreases %.3f of all cells\n",
              b$k, mean(b$declared), mean(inc), mean(dec)))
  reg <- with(r, ifelse(lat >= 32, "Jammu and Kashmir, Ladakh",
             ifelse(lon < 73 & lat >= 22 & lat < 30, "Arid northwest",
             ifelse(lon >= 89 & lat >= 21, "Northeast",
             ifelse(lon >= 73.5 & lon <= 77 & lat <= 21, "West coast and Western Ghats", "Rest of India")))))
  print(round(sapply(split(data.frame(increase = inc, decrease = dec), reg), colMeans), 3))
}

## Same for the 1951-2025 sensitivity run, if available
if (file.exists("results/app_1951_results.csv")) {
  s <- read.csv("results/app_1951_results.csv"); s <- s[!duplicated(s$cell), ]
  s <- merge(s, nz, by = c("lon", "lat")); s <- s[s$frac_zero <= zero_max, ]
  b <- bfdr(s$pr_increase_st, alpha)
  cat(sprintf("\n1951-2025, Bayesian FDR %.2f: threshold %.3f; increases %.3f, decreases %.3f of all cells\n",
              alpha, b$threshold, mean(b$declared & s$pr_increase_st > 0.5),
              mean(b$declared & s$pr_increase_st < 0.5)))
}
