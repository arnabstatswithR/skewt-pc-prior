## =====================================================================
## Figure 1: skew-t densities, skewness, and excess kurtosis
##
## Parameterization of Hazra, Reich and Staicu (2020):
##   Y = mu + sigma * |z| * lambda + sigma * eps,
##   eps ~ N(0, b), z ~ N(0, 1), sigma^2 ~ Inverse-Gamma(a/2, a/2),
## with standardized skewness lambda_star = lambda / sqrt(b).
## Skewness and kurtosis depend only on (a, lambda_star).
##
## Output: figures/st_properties.pdf (used as Fig. 1 in main.tex)
## Packages: ggplot2, patchwork
## =====================================================================

source("R/theme_paper.R")
library(ggplot2)
library(patchwork)

dir.create("figures", showWarnings = FALSE)

## ---------------------------------------------------------------------
## Density of ST(mu, lambda, a, b), Eq. (2) of the manuscript
## ---------------------------------------------------------------------
dst_hrs <- function(y, mu = 0, lambda = 0, a = 5, b = 1) {
  s  <- sqrt(b + lambda^2)          # Azzalini-Capitanio scale
  ls <- lambda / sqrt(b)            # standardized skewness lambda_star
  z  <- (y - mu) / s
  2 / s * dt(z, df = a) * pt(ls * z * sqrt((a + 1) / (a + z^2)), df = a + 1)
}

## ---------------------------------------------------------------------
## Skewness (a > 3) and excess kurtosis (a > 4) as functions of (a, lambda_star)
## ---------------------------------------------------------------------
c_a <- function(a) sqrt(a / pi) * exp(lgamma((a - 1) / 2) - lgamma(a / 2))

st_shape <- function(a, ls) {
  d  <- ls / sqrt(1 + ls^2)         # delta
  m  <- c_a(a) * d                  # mean of the standardized variable
  s2 <- a / (a - 2) - m^2           # variance of the standardized variable
  skew <- m * (a * (3 - d^2) / (a - 3) - 3 * a / (a - 2) + 2 * m^2) / s2^1.5
  kurt <- (3 * a^2 / ((a - 2) * (a - 4)) - 4 * m^2 * a * (3 - d^2) / (a - 3) +
             6 * m^2 * a / (a - 2) - 3 * m^4) / s2^2 - 3
  skew[a <= 3] <- NA
  kurt[a <= 4] <- NA
  data.frame(a = a, ls = ls, skewness = skew, kurtosis = kurt)
}

## Optional check of the closed forms against numerical integration
check_shape <- function(a, ls) {
  f  <- function(y) dst_hrs(y, lambda = ls, a = a, b = 1)
  mk <- sapply(1:4, function(k)
    integrate(function(y) y^k * f(y), -Inf, Inf, rel.tol = 1e-10)$value)
  mu <- mk[1]; v <- mk[2] - mu^2
  m3 <- mk[3] - 3 * mu * mk[2] + 2 * mu^3
  m4 <- mk[4] - 4 * mu * mk[3] + 6 * mu^2 * mk[2] - 3 * mu^4
  rbind(numerical   = c(skewness = m3 / v^1.5, kurtosis = m4 / v^2 - 3),
        closed_form = unlist(st_shape(a, ls)[, c("skewness", "kurtosis")]))
}
print(check_shape(a = 6, ls = 2))   # both rows should agree

## ---------------------------------------------------------------------
## Left panel: densities (mu = 0, b = 1, so lambda = lambda_star)
## ---------------------------------------------------------------------
y_grid <- seq(-4, 8, length.out = 1000)
settings <- expand.grid(a = c(3, 30), ls = c(0, 1, 5))

dens <- do.call(rbind, lapply(seq_len(nrow(settings)), function(j) {
  a <- settings$a[j]; ls <- settings$ls[j]
  data.frame(y = y_grid,
             density = dst_hrs(y_grid, mu = 0, lambda = ls, a = a, b = 1),
             a = factor(paste0("a = ", a), levels = c("a = 3", "a = 30")),
             ls = factor(ls))
}))

p1 <- ggplot(dens, aes(x = y, y = density, colour = ls, linetype = a)) +
  geom_line(linewidth = 0.6) +
  scale_colour_manual(values = c("0" = "black", "1" = "#1b9e77", "5" = "#d95f02"),
                      name = expression(lambda^"*")) +
  scale_linetype_manual(values = c("a = 3" = "solid", "a = 30" = "dashed"),
                        name = NULL) +
  labs(x = "y", y = NULL) +
  labs(title = "Density") +
  theme_paper() +
  theme(legend.position = "bottom", legend.box = "vertical", legend.spacing.y = unit(0, "cm"),
        legend.margin = margin(0, 0, 0, 0), legend.key.width = unit(0.7, "cm")) +
  guides(colour = guide_legend(order = 1, nrow = 1, override.aes = list(linewidth = 1.2)), linetype = guide_legend(order = 2, nrow = 1))

## ---------------------------------------------------------------------
## Middle and right panels: skewness and excess kurtosis surfaces
## ---------------------------------------------------------------------
surf <- st_shape(a  = rep(seq(5, 30, length.out = 200), times = 201),
                 ls = rep(seq(-5, 5, length.out = 201), each = 200))

surface_plot <- function(var, title, trans = "identity") {
  ggplot(surf, aes(x = a, y = ls, z = .data[[var]], fill = .data[[var]])) +
    geom_raster() +
    geom_contour(colour = "white", linewidth = 0.25, bins = 10) +
    scale_fill_viridis_c(name = NULL, trans = trans) +
    scale_x_continuous(expand = c(0, 0)) +
    scale_y_continuous(expand = c(0, 0)) +
    labs(x = "Degrees of freedom a", y = expression(lambda^"*"), title = title) +
    theme_paper() +
    theme(legend.position = "bottom", legend.key.width = unit(1.1, "cm"),
          legend.key.height = unit(0.3, "cm"), legend.margin = margin(0, 0, 0, 0))
}

p2 <- surface_plot("skewness", "Skewness")
## excess kurtosis ranges from about 0.2 to 18 on this grid, so use a log color scale
p3 <- surface_plot("kurtosis", "Excess kurtosis", trans = "log10")

fig1 <- p1 + p2 + p3 + plot_layout(widths = c(1, 1, 1))
ggsave("figures/st_properties.pdf", fig1, width = fig_width, height = 3.6)
