## =====================================================================
## Remark 5.1: data-augmented Gibbs sampler versus the marginal-likelihood
## sampler (skewt_mcmc), compared by effective sample size (ESS).
##
## Data augmentation uses v_i = sigma_i |z_i| in Eq. (3):
##   Y_i = mu_i + lambda v_i + sigma_i eps_i,  eps_i ~ N(0, b),
##   v_i | sigma_i ~ N+(0, sigma_i^2),  sigma_i^2 ~ IG(a/2, a/2),
## which gives closed-form full conditionals for v_i, sigma_i^2, and beta.
##
## Requires: R/pc_prior_functions.R, R/skewt_mcmc.R; package coda.
## =====================================================================

source("R/pc_prior_functions.R")
source("R/skewt_mcmc.R")
library(coda)

## truncated N+(m, s^2) on (0, Inf), vectorized and numerically stable
rtnorm_pos <- function(m, s) {
  lp0 <- pnorm(-m / s, lower.tail = FALSE, log.p = TRUE)      # log P(Z > -m/s)
  z   <- qnorm(log(runif(length(m))) + lp0, lower.tail = FALSE, log.p = TRUE)
  m + s * z
}

skewt_da_mcmc <- function(y, B, n_iter = 25000, n_burn = 12500, thin = 5,
                          hyper = list(sd_beta = 10, b_shape = 0.01, b_rate = 0.01,
                                       theta_a = 5.10, theta_l = 1.66),
                          grid, adapt_every = 100, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  n <- length(y); K <- ncol(B)
  beta <- as.numeric(qr.solve(B, y)); lambda <- 0; a <- 10
  b <- as.numeric(var(as.numeric(y - B %*% beta))) * (a - 2) / a
  sig2 <- rep(1, n); v <- abs(rnorm(n))
  mu <- as.numeric(B %*% beta)
  sd_xi <- 0.5; acc_xi <- 0; acc_l <- 0; acc_b <- 0
  P0 <- diag(1 / hyper$sd_beta^2, K)

  keep <- seq(n_burn + thin, n_iter, by = thin)
  keep_flag <- logical(n_iter); keep_flag[keep] <- TRUE
  out <- matrix(NA_real_, length(keep), K + 3,
                dimnames = list(NULL, c(paste0("beta", 1:K), "lambda", "a", "b")))
  r_out <- 0

  for (it in 1:n_iter) {
    r <- y - mu

    ## v_i | rest ~ N+( lambda r / (b + lambda^2), sig2 b / (b + lambda^2) )
    v <- rtnorm_pos(lambda * r / (b + lambda^2), sqrt(sig2 * b / (b + lambda^2)))

    ## sigma_i^2 | rest ~ IG( a/2 + 1, a/2 + v^2/2 + (r - lambda v)^2 / (2b) )
    sig2 <- 1 / rgamma(n, shape = a / 2 + 1,
                       rate = a / 2 + v^2 / 2 + (r - lambda * v)^2 / (2 * b))

    ## beta | rest: Gaussian (weighted regression of y - lambda v on B)
    w    <- 1 / (sig2 * b)
    Prec <- crossprod(B, B * w) + P0
    R    <- chol(Prec)
    mean_beta <- backsolve(R, forwardsolve(t(R), crossprod(B, w * (y - lambda * v))))
    beta <- as.numeric(mean_beta + backsolve(R, rnorm(K)))
    mu   <- as.numeric(B %*% beta); r <- y - mu

    ## lambda | rest: independence MH with the Gaussian likelihood term as proposal,
    ## so the acceptance ratio is the PC prior ratio
    q   <- sum(v^2 / (sig2 * b)); m_l <- sum(v * r / (sig2 * b)) / q
    lambda_p <- rnorm(1, m_l, 1 / sqrt(q))
    if (log(runif(1)) < log_prior_lambda(lambda_p, a, b, hyper$theta_l, grid) -
                        log_prior_lambda(lambda,   a, b, hyper$theta_l, grid)) {
      lambda <- lambda_p; acc_l <- acc_l + 1
    }

    ## b | rest: independence MH with the IG part of the full conditional
    ## as proposal; acceptance ratio is the ratio of the PC prior for lambda
    shp  <- hyper$b_shape + n / 2
    rte  <- hyper$b_rate + sum((r - lambda * v)^2 / sig2) / 2
    b_p  <- 1 / rgamma(1, shape = shp, rate = rte)
    if (log(runif(1)) < log_prior_lambda(lambda, a, b_p, hyper$theta_l, grid) -
                        log_prior_lambda(lambda, a, b,   hyper$theta_l, grid)) {
      b <- b_p; acc_b <- acc_b + 1
    }

    ## a | rest: random walk on xi = log(a - 2)
    lfa <- function(aa) sum(dgamma(1 / sig2, shape = aa / 2, rate = aa / 2, log = TRUE)) +
      log_pc_a(aa, hyper$theta_a) + log_prior_lambda(lambda, aa, b, hyper$theta_l, grid)
    a_p <- 2 + exp(log(a - 2) + rnorm(1, 0, sd_xi))
    if (log(runif(1)) < (lfa(a_p) + log(a_p - 2)) - (lfa(a) + log(a - 2))) {
      a <- a_p; acc_xi <- acc_xi + 1
    }
    ## note: dgamma on 1/sig2 is the Gamma(a/2, a/2) density of the precision;
    ## the Jacobian of 1/sig2 does not depend on a, so it cancels in the ratio.

    if (it <= n_burn && it %% adapt_every == 0) {
      rate  <- acc_xi / adapt_every
      sd_xi <- if (rate < 0.3) sd_xi * 0.8 else if (rate > 0.5) sd_xi * 1.2 else sd_xi
      acc_xi <- 0
    }
    if (keep_flag[it]) { r_out <- r_out + 1; out[r_out, ] <- c(beta, lambda, a, b) }
  }
  cbind(out, lambda_star = out[, "lambda"] / sqrt(out[, "b"]))
}

## =====================================================================
## Comparison on simulated data (n = 125 annual maxima, K = 12)
## =====================================================================
grid <- build_ls_grid()
set.seed(2026)
n <- 125; t <- 1901:2025
mu_true <- 60 + 8 * sin(2 * pi * (t - 1901) / 60)
lambda <- 20; a <- 6; b <- 100
sig <- sqrt(1 / rgamma(n, a / 2, a / 2))
y <- mu_true + sig * abs(rnorm(n)) * lambda + sig * rnorm(n, 0, sqrt(b))
B <- bspline_basis(t, K = 12)
y_std <- (y - mean(y)) / sd(y)        # the DA sampler works on the standardized scale;
                                      # ESS is invariant to this transformation
time_m <- system.time(fit_m <- skewt_mcmc(y, B, grid = grid, seed = 1, verbose = FALSE))
time_d <- system.time(fit_d <- skewt_da_mcmc(y_std, B, grid = grid, seed = 1))

pars <- c("lambda", "a", "b", "lambda_star")
ess  <- rbind(marginal          = effectiveSize(as.mcmc(fit_m$samples[, pars])),
              data_augmentation = effectiveSize(as.mcmc(fit_d[, pars])))
print(round(ess))
print(round(ess / c(time_m["elapsed"], time_d["elapsed"]), 1))   # ESS per second
## Report both tables in Remark 5.1.
