## =====================================================================
## Section 7 data: summer monsoon (June-September) rainfall totals from the
## IMD 0.25-degree daily gridded data, 1901-2025
##
## Uses data/jjas_total.rds (created by scripts/08_data_jjas_totals.R from the yearly
## NetCDF files). Cells with a JJAS total of exactly zero in more than 25% of
## the years are removed (outside the effective coverage of the gauge network).
##
## Output:
##   data/jjas_long.csv     one row per retained cell and year: cell, lon, lat, year, y
##   figures/jjas_map.pdf   mean and SD of the JJAS totals, for a quick check
## Run: Rscript scripts/09_data_long.R
## =====================================================================

library(ggplot2)
library(patchwork)

d <- readRDS("data/jjas_total.rds")
tot <- d$total; lon <- d$lon; lat <- d$lat; years <- d$year
land <- d$land

n_zero <- apply(tot == 0, 1:2, sum)
removed <- land & n_zero > 0.25 * length(years)
keep <- land & !removed
cat("Land cells:", sum(land), "| removed (zero JJAS total in more than 25% of the years):",
    sum(removed), "| retained:", sum(keep), "\n")

idx <- which(keep, arr.ind = TRUE)
ny <- length(years)
long <- data.frame(cell = rep(seq_len(nrow(idx)), each = ny),
                   lon  = rep(lon[idx[, 1]], each = ny),
                   lat  = rep(lat[idx[, 2]], each = ny),
                   year = rep(years, nrow(idx)),
                   y    = as.vector(apply(idx, 1, function(i) tot[i[1], i[2], ])))
stopifnot(all.equal(long$y[long$cell == 1], tot[idx[1, 1], idx[1, 2], ]))
write.csv(long, "data/jjas_long.csv", row.names = FALSE)
cat("Saved data/jjas_long.csv:", nrow(idx), "cells x", ny, "years\n")

summ <- aggregate(y ~ cell + lon + lat, long, function(z) c(mean = mean(z), sd = sd(z)))
summ <- data.frame(summ[, 1:3], mean = summ$y[, "mean"], sd = summ$y[, "sd"])
mp <- function(v, ttl) ggplot(summ, aes(lon, lat, fill = .data[[v]])) + geom_raster() +
  coord_equal() + scale_fill_viridis_c(name = "mm", trans = "log10") +
  labs(title = ttl, x = "Longitude", y = "Latitude") + theme_bw(base_size = 10)
ggsave("figures/jjas_map.pdf",
       mp("mean", "Mean JJAS rainfall total") + mp("sd", "SD of JJAS rainfall total"),
       width = 9, height = 4.5)
