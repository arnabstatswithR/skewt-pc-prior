## =====================================================================
## Exploratory check: is monsoon (June-September) total rainfall skewed and
## heavy-tailed enough to motivate the skew-t model?
##
## Uses the yearly IMD 0.25-degree NetCDF files already in data/imd_raw/
## (downloaded by scripts/07_data_download.R).
## Output:
##   console: summaries of per-cell skewness and excess kurtosis
##   data/jjas_total.rds        list(lon, lat, year, total[lon, lat, year], land[lon, lat])
##   figures/jjas_moments.pdf   maps of mean, skewness and excess kurtosis
## Run from the project folder:  Rscript scripts/08_data_jjas_totals.R
## Packages: ncdf4, ggplot2, patchwork
## =====================================================================

library(ncdf4)
library(ggplot2)
library(patchwork)

years   <- 1901:2025
raw_dir <- "data/imd_raw"
dir.create("figures", showWarnings = FALSE)

find_file <- function(y) {
  f <- list.files(raw_dir, pattern = paste0(y, ".*\\.nc$"), full.names = TRUE)
  if (!length(f)) stop("No NetCDF file for ", y, " in ", raw_dir)
  f[1]
}

## Read one year as a lon x lat x day array (dimension order detected from names)
read_year <- function(f) {
  nc <- nc_open(f); on.exit(nc_close(nc))
  v  <- names(nc$var)[vapply(nc$var, function(x) x$ndims == 3, logical(1))][1]
  dn <- vapply(nc$var[[v]]$dim, function(d) toupper(d$name), character(1))
  x  <- ncvar_get(nc, v)
  lon <- ncvar_get(nc, nc$var[[v]]$dim[[grep("LON", dn)]]$name)
  lat <- ncvar_get(nc, nc$var[[v]]$dim[[grep("LAT", dn)]]$name)
  x  <- aperm(x, c(grep("LON", dn), grep("LAT", dn), grep("TIME", dn)))
  x[x < 0 | x > 2000] <- NA                       # fill values (-999) and impossible values
  list(lon = as.numeric(lon), lat = as.numeric(lat), x = x)
}

## ------------------------- JJAS totals --------------------------------
total <- NULL
for (k in seq_along(years)) {
  d <- read_year(find_file(years[k]))
  nd <- dim(d$x)[3]
  leap <- nd == 366
  jjas <- (152:273) + leap                        # 1 June to 30 September
  nv  <- apply(!is.na(d$x[, , jjas]), 1:2, sum)
  s   <- apply(d$x[, , jjas], 1:2, sum, na.rm = TRUE)
  s[nv < 0.9 * length(jjas)] <- NA                # fewer than 90% of days available
  if (is.null(total)) {
    lon <- d$lon; lat <- d$lat
    total <- array(NA_real_, c(length(lon), length(lat), length(years)))
  }
  total[, , k] <- s
  if (k %% 25 == 0) cat("read", years[k], "\n")
}
land <- apply(!is.na(total), 1:2, all)
cat("\nLand cells with complete JJAS totals:", sum(land), "\n")
saveRDS(list(lon = lon, lat = lat, year = years, total = total, land = land),
        "data/jjas_total.rds")

## ------------------------- moments per cell ---------------------------
## Moments of the residuals from a smooth trend (natural spline, 4 df), so that
## multidecadal variation in the mean is not mistaken for skewness or heavy tails.
library(splines)
X <- ns(years, df = 4)
mom <- function(z) {
  r <- residuals(lm(z ~ X)); r <- (r - mean(r)) / sd(r)
  c(skew = mean(r^3), exkurt = mean(r^4) - 3)
}
idx <- which(land, arr.ind = TRUE)
M <- t(apply(idx, 1, function(i) mom(total[i[1], i[2], ])))
res <- data.frame(lon = lon[idx[, 1]], lat = lat[idx[, 2]],
                  mean = apply(idx, 1, function(i) mean(total[i[1], i[2], ])), M)

cat("\nSkewness of detrended JJAS totals:\n");          print(summary(res$skew))
cat("\nExcess kurtosis of detrended JJAS totals:\n");   print(summary(res$exkurt))
## Under Gaussianity with n = 125, the standard errors are about 0.22 (skewness)
## and 0.43 (excess kurtosis), so values beyond about 0.5 and 1 are notable.
cat("\nShare of cells with |skewness| > 0.5:  ", round(mean(abs(res$skew) > 0.5), 3), "\n")
cat("Share of cells with excess kurtosis > 1:", round(mean(res$exkurt > 1), 3), "\n")
cat("Share of cells with both:              ",
    round(mean(abs(res$skew) > 0.5 & res$exkurt > 1), 3), "\n")

## ------------------------- maps ---------------------------------------
mp <- function(v, ttl, ...) ggplot(res, aes(lon, lat, fill = .data[[v]])) + geom_raster() +
  coord_equal() + labs(title = ttl, x = "Longitude", y = "Latitude", fill = NULL) +
  theme_bw(base_size = 10) + ...
lim <- max(abs(res$skew))
fig <- mp("mean", "Mean JJAS total (mm)", scale_fill_viridis_c(trans = "log10")) +
  mp("skew", "Skewness (detrended)",
     scale_fill_gradient2(low = "#2166ac", mid = "white", high = "#b2182b", limits = c(-lim, lim))) +
  mp("exkurt", "Excess kurtosis (detrended)",
     scale_fill_gradient2(low = "#2166ac", mid = "white", high = "#b2182b", midpoint = 0))
ggsave("figures/jjas_moments.pdf", fig, width = 12, height = 4.2)
cat("\nSaved data/jjas_total.rds and figures/jjas_moments.pdf\n")
