## =====================================================================
## Section 7.2: example cells. For six representative cells, the proposed
## model (skew-t, joint PC prior) and the semiparametric Gaussian model are
## refitted, and two figures are drawn:
##   figures/app_cells_series.pdf  JJAS totals (mm) with the fitted 0.1, 0.5 and
##                                 0.9 quantile curves over time (posterior means
##                                 and 95% bands), proposed vs Gaussian
##   figures/app_cells_resid.pdf   histograms of the residuals from the fitted
##                                 location (square-root scale) with the fitted
##                                 skew-t and Gaussian densities
## Run: Rscript scripts/15_application_example_cells.R      Packages: sn, ggplot2, patchwork
## =====================================================================

source("R/pc_prior_functions.R")
source("R/skewt_mcmc.R")
source("R/theme_paper.R")
library(sn); library(ggplot2); library(patchwork)

## Representative cells (nearest grid cell to these coordinates); edit as needed
sites <- data.frame(
  name = c("Leh\n(Ladakh)", "Cherrapunji\n(Northeast India)", "Mahabaleshwar\n(Western Ghats)",
           "Jaisalmer\n(Thar Desert)", "Jabalpur\n(Central India)", "Patna\n(Gangetic Plain)"),
  lon = c(77.58, 91.73, 73.66, 70.91, 79.95, 85.14),
  lat = c(34.16, 25.28, 17.92, 26.92, 23.18, 25.59))
mcmc <- list(n_iter = 20000, n_burn = 10000, thin = 10)
K <- 12; probs <- c(0.1, 0.5, 0.9); n_draw <- 300

grid  <- build_ls_grid()
dat   <- read.csv("data/jjas_long.csv")
years <- sort(unique(dat$year))
B     <- bspline_basis(years, K)
cells <- unique(dat[, c("cell", "lon", "lat")])
sites$cell <- sapply(seq_len(nrow(sites)), function(i)
  cells$cell[which.min((cells$lon - sites$lon[i])^2 + (cells$lat - sites$lat[i])^2)])

gaussian_mcmc <- function(y, B, n_iter, n_burn, thin) {        # as in scripts/11_application_fit.R
  n <- length(y); Kb <- ncol(B); yc <- mean(y); ys <- sd(y); z <- (y - yc) / ys
  v_one <- as.numeric(qr.coef(qr(B), rep(1, n))); v_one[is.na(v_one)] <- 0
  BtB <- crossprod(B); Btz <- crossprod(B, z); s2 <- 1
  keep <- seq(n_burn + thin, n_iter, by = thin)
  bo <- matrix(NA_real_, length(keep), Kb); so <- numeric(length(keep)); r <- 0
  for (it in 1:n_iter) {
    R <- chol(BtB / s2 + diag(1 / 100, Kb))
    beta <- as.numeric(backsolve(R, forwardsolve(t(R), Btz / s2)) + backsolve(R, rnorm(Kb)))
    s2 <- 1 / rgamma(1, 0.01 + n / 2, 0.01 + sum((z - B %*% beta)^2) / 2)
    if (it %in% keep) { r <- r + 1; bo[r, ] <- beta; so[r] <- s2 }
  }
  list(beta = sweep(ys * bo, 2, yc * v_one, "+"), sd = ys * sqrt(so))
}

band <- function(M) data.frame(mean = colMeans(M), lo = apply(M, 2, quantile, 0.025),
                               hi = apply(M, 2, quantile, 0.975))
series <- list(); resid <- list(); dens <- list()
for (i in seq_len(nrow(sites))) {
  d <- dat[dat$cell == sites$cell[i], ]; d <- d[order(d$year), ]; y <- sqrt(d$y)
  set.seed(i)
  f <- do.call(skewt_mcmc, c(list(y = y, B = B, prior = "pc", family = "st", grid = grid,
                                  beta_block = TRUE, verbose = FALSE), mcmc))
  g <- do.call(gaussian_mcmc, c(list(y = y, B = B), mcmc))
  S <- f$samples; idx <- round(seq(1, nrow(S), length.out = n_draw))
  mu_st <- S[idx, 1:K] %*% t(B); mu_g <- g$beta[idx, ] %*% t(B)
  for (p in probs) {
    qe <- mapply(function(l, a, b) qst(p, 0, sqrt(b + l^2), l / sqrt(b), a),
                 S[idx, "lambda"], S[idx, "a"], S[idx, "b"])
    q_st <- pmax(mu_st + qe, 0)^2                               # back to mm
    q_g  <- pmax(mu_g + qnorm(p) * g$sd[idx], 0)^2
    series[[length(series) + 1]] <- rbind(
      data.frame(site = sites$name[i], year = years, p = p, model = "Skew-t (PC)", band(q_st)),
      data.frame(site = sites$name[i], year = years, p = p, model = "Gaussian", band(q_g)))
  }
  ## residuals from the posterior-mean location of the proposed model, and the
  ## fitted error densities at the posterior means of the parameters
  res <- y - colMeans(S[, 1:K] %*% t(B))
  resid[[i]] <- data.frame(site = sites$name[i], res = res)
  xx <- seq(min(res) - 0.5 * sd(res), max(res) + 0.5 * sd(res), length.out = 300)
  lam <- mean(S[, "lambda"]); aa <- median(S[, "a"]); bb <- mean(S[, "b"])
  res_g <- y - colMeans(g$beta %*% t(B))
  dens[[i]] <- rbind(
    data.frame(site = sites$name[i], x = xx, model = "Skew-t (PC)",
               d = dst(xx, 0, sqrt(bb + lam^2), lam / sqrt(bb), aa)),
    data.frame(site = sites$name[i], x = xx, model = "Gaussian",
               d = dnorm(xx, mean(res - res_g), mean(g$sd))))   # Gaussian mean in the residual coordinates
  cat("fitted", sites$name[i], "\n")
}
series <- do.call(rbind, series); resid <- do.call(rbind, resid); dens <- do.call(rbind, dens)
obs <- merge(dat, data.frame(cell = sites$cell, site = sites$name))
for (nm in c("series", "resid", "dens", "obs")) {           # panels in the order of "sites"
  x <- get(nm); x$site <- factor(x$site, levels = sites$name); assign(nm, x)
}

th <- theme_paper() + theme(legend.position = "bottom")
cols <- c("Skew-t (PC)" = "#d95f02", "Gaussian" = "grey35")   # same model colors as in figures/app_comparison.pdf
p1 <- ggplot() +
  geom_col(data = obs, aes(year, y), fill = "grey75", width = 0.8) +
  geom_ribbon(data = series, aes(year, ymin = lo, ymax = hi, fill = model, group = interaction(model, p)), alpha = 0.2) +
  geom_line(data = series, aes(year, mean, colour = model, linetype = factor(p),
                               group = interaction(model, p)), linewidth = 0.6) +
  facet_wrap(~ site, ncol = 2, scales = "free_y") +
  scale_colour_manual(values = cols) + scale_fill_manual(values = cols, guide = "none") +
  scale_linetype_manual(values = c("dashed", "solid", "dotted"), name = "Quantile") +
  labs(x = "Year", y = "JJAS total (mm)", colour = NULL) + th
ggsave("figures/app_cells_series.pdf", p1, width = fig_width, height = 9)

p2 <- ggplot(resid, aes(res)) +
  geom_histogram(aes(y = after_stat(density)), bins = 25, fill = "grey80", colour = "grey50") +
  geom_line(data = dens, aes(x, d, colour = model), linewidth = 0.8) +
  facet_wrap(~ site, ncol = 3, scales = "free") +
  scale_colour_manual(values = cols, guide = guide_legend(override.aes = list(linewidth = 1.2))) +
  labs(x = "Residual (square-root scale)", y = "Density", colour = NULL) + th
ggsave("figures/app_cells_resid.pdf", p2, width = fig_width, height = 5.6)
cat("Saved figures/app_cells_series.pdf and figures/app_cells_resid.pdf\n")
