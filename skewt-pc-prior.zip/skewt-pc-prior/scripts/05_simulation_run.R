## =====================================================================
## Section 6: simulation study -- model fitting
##
## Run from the project folder:   Rscript scripts/05_simulation_run.R
## Each configuration is saved to results/sim/<config>.rds, so the script
## can be stopped and restarted; finished configurations are skipped.
## Then run scripts/06_simulation_summarize.R for the tables and figures.
##
## Requires: R/pc_prior_functions.R, R/skewt_mcmc.R; packages: splines, parallel
## =====================================================================

source("R/pc_prior_functions.R")
source("R/skewt_mcmc.R")
library(parallel)

## ------------------------- user settings ------------------------------
n_rep   <- 500                     # replicates per configuration (paper: 500)
n_cores <- max(1, detectCores() - 1)
mcmc    <- list(n_iter = 10000, n_burn = 5000, thin = 5)
out_dir <- "results/sim"
## ----------------------------------------------------------------------

dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
grid <- build_ls_grid()

beta_true <- c(1, 2, -1)           # mu = beta0 + beta1 * f1(x1) + beta2 * f2(x2)
b_true    <- 1

truths <- data.frame(label = c("Gaussian", "Student-t", "Skew-normal", "Skew-t"),
                     a     = c(Inf, 5, Inf, 5),
                     ls    = c(0, 0, 3, 3))

hyper_default <- list(sd_beta = 10, b_shape = 0.01, b_rate = 0.01,
                      theta_a = 5.10,  theta_l = 1.66)
hyper_conc    <- modifyList(hyper_default, list(theta_a = 11.83, theta_l = 3.48))

## Configurations: the eight settings of Table 2 (2 DGPs x 2 fitted models x
## {conventional = "hrs", PC = "pc"}), plus, for the semiparametric fit only,
## the Gamma(2, 0.1) benchmark ("js") and the concentrated PC prior ("pc_conc").
base <- expand.grid(n = c(50, 200), truth = truths$label,
                    dgp = c("linear", "nonlinear"), fit = c("parametric", "semiparametric"),
                    prior = c("hrs", "pc"), stringsAsFactors = FALSE)
extra <- expand.grid(n = c(50, 200), truth = truths$label,
                     dgp = c("linear", "nonlinear"), fit = "semiparametric",
                     prior = c("js", "pc_conc"), stringsAsFactors = FALSE)
configs <- rbind(base, extra)
configs$setting <- with(configs,
  1 + (dgp == "nonlinear") + 2 * (prior %in% c("pc", "pc_conc")) + 4 * (fit == "semiparametric"))
configs$setting[configs$prior %in% c("js", "pc_conc")] <- NA   # not in Table 2
cat(nrow(configs), "configurations x", n_rep, "replicates\n")

## ------------------------- data and design ----------------------------
simulate_data <- function(n, dgp, a, ls) {
  x1 <- seq(0, 1, length.out = n + 2)[-c(1, n + 2)]      # equally spaced on (0, 1)
  x2 <- runif(n, 0, 0.5)
  mu <- if (dgp == "linear") beta_true[1] + beta_true[2] * x1 + beta_true[3] * x2 else
    beta_true[1] + beta_true[2] * x1^2 + beta_true[3] * sin(2 * pi * x2)
  lambda <- ls * sqrt(b_true)                             # lambda* = lambda / sqrt(b)
  sigma  <- if (is.infinite(a)) rep(1, n) else sqrt(1 / rgamma(n, a / 2, a / 2))
  y <- mu + sigma * abs(rnorm(n)) * lambda + sigma * rnorm(n, 0, sqrt(b_true))   # Eq. (3)
  list(y = y, x1 = x1, x2 = x2, mu = mu)
}

design_matrix <- function(d, fit, K1 = 6, K2 = 6) {
  if (fit == "parametric") return(cbind(1, d$x1, d$x2))
  B1 <- bspline_basis(d$x1, K1, range_x = c(0, 1))        # sums to one: carries the level
  B2 <- bspline_basis(d$x2, K2, range_x = c(0, 0.5))
  B2 <- sweep(B2, 2, colMeans(B2))[, -K2]                 # centered, one column dropped
  cbind(B1, B2)
}

## ------------------------- one replicate ------------------------------
one_rep <- function(r, cfg) tryCatch(one_rep_inner(r, cfg),
  error = function(e) paste("replicate", r, ":", conditionMessage(e)))

one_rep_inner <- function(r, cfg) {
  set.seed(1e5 * cfg$id + r)
  tr <- truths[truths$label == cfg$truth, ]
  d  <- simulate_data(cfg$n, cfg$dgp, tr$a, tr$ls)
  B  <- design_matrix(d, cfg$fit)
  prior <- if (cfg$prior == "pc_conc") "pc" else cfg$prior
  hyper <- if (cfg$prior == "pc_conc") hyper_conc else hyper_default
  t0 <- proc.time()[["elapsed"]]
  fit <- do.call(skewt_mcmc, c(list(y = d$y, B = B, prior = prior, hyper = hyper,
                                    grid = grid, beta_block = TRUE, verbose = FALSE), mcmc))
  elapsed <- proc.time()[["elapsed"]] - t0
  S   <- fit$samples
  tau <- 1 / S[, "a"]; ls <- S[, "lambda_star"]
  mu_hat <- as.numeric(B %*% colMeans(S[, 1:ncol(B), drop = FALSE]))
  data.frame(rep = r,
             tau_mean = mean(tau), tau_median = median(tau),
             tau_q025 = quantile(tau, 0.025), tau_q975 = quantile(tau, 0.975),
             ls_mean = mean(ls), ls_median = median(ls),
             ls_q025 = quantile(ls, 0.025), ls_q975 = quantile(ls, 0.975),
             prob_a_gt_30 = mean(S[, "a"] > 30),
             fit_error = sum(abs(d$mu - mu_hat)),
             waic = waic(fit$loglik)[["WAIC"]], dic = dic(fit, d$y, B)[["DIC"]],
             acc_a = fit$acceptance[["log_a"]], time = elapsed,
             row.names = NULL)
}

## ------------------------- main loop ----------------------------------
for (i in seq_len(nrow(configs))) {
  cfg <- as.list(configs[i, ]); cfg$id <- i
  file <- file.path(out_dir, sprintf("cfg%03d_n%d_%s_%s_%s_%s.rds", i, cfg$n,
                                     gsub("[^A-Za-z]", "", cfg$truth), cfg$dgp, cfg$fit, cfg$prior))
  if (file.exists(file)) next
  cat(sprintf("[%s] config %d/%d: n=%d, %s, %s, %s, %s\n", format(Sys.time(), "%H:%M"),
              i, nrow(configs), cfg$n, cfg$truth, cfg$dgp, cfg$fit, cfg$prior))
  res <- if (.Platform$OS.type == "unix") {
    mclapply(seq_len(n_rep), one_rep, cfg = cfg, mc.cores = n_cores)
  } else {
    cl <- makeCluster(n_cores)
    clusterExport(cl, ls(globalenv())); clusterEvalQ(cl, library(splines))
    out <- parLapply(cl, seq_len(n_rep), one_rep, cfg = cfg); stopCluster(cl); out
  }
  ok  <- vapply(res, is.data.frame, logical(1))
  if (any(!ok)) {
    cat("  ", sum(!ok), "replicates failed; first error:\n   ",
        as.character(res[!ok][[1]]), "\n")
  }
  if (!any(ok)) next                                  # nothing saved: rerun later
  res <- do.call(rbind, res[ok])
  saveRDS(list(config = configs[i, ], results = res), file)
}
cat("Done.\n")
