## =====================================================================
## Figure 2: PC priors
##   left:   pi_PC(a) for several theta_a                       (Eq. 7)
##   middle: pi_PC(lambda* | a) for several theta_lambda         (Eq. 8)
##   right:  contours of the joint prior pi_PC(a) pi_PC(lambda* | a)
##           under the default hyperparameters                   (Eq. 6)
##
## Output: figures/pc_priors.pdf
## Packages: ggplot2, patchwork
## Run time: about a minute (numerical integrals for the joint prior).
## =====================================================================

source("R/theme_paper.R")
library(ggplot2)
library(patchwork)
dir.create("figures", showWarnings = FALSE)

## ---------------------------------------------------------------------
## Distance for a (Theorem 4.1) and its derivative
## ---------------------------------------------------------------------
kld_a <- function(a) {
  0.5 * log(2 * pi * a / (a - 2)) + 0.5 -
    (a + 1) / 2 * (digamma((a + 1) / 2) - digamma(a / 2)) -
    (0.5 * log(a) + lbeta(a / 2, 0.5))
}
dkld_a <- function(a) {
  (a + 1) / 4 * (trigamma(a / 2) - trigamma((a + 1) / 2)) - 1 / (2 * (a - 2))
}
d_a  <- function(a) sqrt(2 * kld_a(a))
dd_a <- function(a) dkld_a(a) / d_a(a)                 # d'(a) = KLD'(a) / d(a)

pc_a <- function(a, theta) theta * exp(-theta * d_a(a)) * abs(dd_a(a))

## ---------------------------------------------------------------------
## Conditional distance for lambda* given a (Theorem 4.2)
## ---------------------------------------------------------------------
binary_entropy <- function(u) {
  u <- pmin(pmax(u, 1e-300), 1 - 1e-16)
  -u * log(u) - (1 - u) * log1p(-u)
}
kld_ls <- function(ls, a) {                            # a = Inf: skew-normal
  if (ls == 0) return(0)
  if (is.infinite(a)) {
    g <- function(z) 2 * dnorm(z) * (log(2) - binary_entropy(pnorm(ls * z)))
  } else {
    g <- function(z) 2 * dt(z, a) *
      (log(2) - binary_entropy(pt(ls * z * sqrt((a + 1) / (a + z^2)), a + 1)))
  }
  integrate(g, 0, Inf, rel.tol = 1e-10, subdivisions = 1000L)$value
}
d_max <- sqrt(2 * log(2))

## d(lambda* | a) on a grid of lambda* >= 0, interpolated by a monotone spline;
## the prior is symmetric in lambda*, so we evaluate it at |lambda*|.
make_d_ls <- function(a, ls_max = 50, n = 400) {
  ls_grid <- c(0, exp(seq(log(1e-3), log(ls_max), length.out = n)))
  d_grid  <- sqrt(2 * sapply(ls_grid, kld_ls, a = a))
  splinefun(ls_grid, d_grid, method = "monoH.FC")
}

pc_ls <- function(ls, theta, dfun) {
  x <- abs(ls)
  theta * exp(-theta * dfun(x)) / (2 * (1 - exp(-theta * d_max))) *
    abs(dfun(x, deriv = 1))
}

## ---------------------------------------------------------------------
## Hyperparameters (Section 4.2.3)
## ---------------------------------------------------------------------
theta_a_def <- 5.10;  theta_a_con <- 11.83
theta_l_def <- 1.66;  theta_l_con <- 3.48

## ---------------------------------------------------------------------
## Left panel: pi_PC(a)
## ---------------------------------------------------------------------
a_grid <- seq(2.02, 60, length.out = 1500)
prior_a <- rbind(
  data.frame(a = a_grid, density = pc_a(a_grid, theta_a_def), setting = "default"),
  data.frame(a = a_grid, density = pc_a(a_grid, theta_a_con), setting = "concentrated"))
prior_a$setting <- factor(prior_a$setting, levels = c("default", "concentrated"))

## check: the prior integrates to 1 over (2, Inf)
print(integrate(pc_a, 2 + 1e-9, Inf, theta = theta_a_def)$value)

p1 <- ggplot(prior_a, aes(a, density, linetype = setting)) +
  geom_line(linewidth = 0.6) +
  scale_linetype_manual(values = c(default = "solid", concentrated = "dashed"),
                        breaks = c("default", "concentrated"),
                        labels = expression(theta[a] == "5.10", theta[a] == "11.83"),
                        name = NULL) +
  labs(x = "Degrees of freedom a", y = NULL, title = "Prior for a") +
  theme_paper() +
  theme(legend.key.width = unit(0.7, "cm")) +
  guides(linetype = guide_legend(nrow = 2))

## ---------------------------------------------------------------------
## Middle panel: pi_PC(lambda* | a) for a = Inf (skew-normal).
## The curves for finite a (e.g., a = 5) lie almost exactly on top of these
## (Remark 4.4), so they are not drawn; the check below quantifies this.
## ---------------------------------------------------------------------
d_ls_5   <- make_d_ls(5)
d_ls_inf <- make_d_ls(Inf)

ls_grid <- seq(-4, 4, length.out = 801)
prior_ls <- rbind(
  data.frame(ls = ls_grid, density = pc_ls(ls_grid, theta_l_def, d_ls_inf),
             theta = "default"),
  data.frame(ls = ls_grid, density = pc_ls(ls_grid, theta_l_con, d_ls_inf),
             theta = "concentrated"))
prior_ls$theta <- factor(prior_ls$theta, levels = c("default", "concentrated"))

## check: the conditional prior integrates to 1 over the real line
print(2 * integrate(pc_ls, 0, Inf, theta = theta_l_def, dfun = d_ls_inf,
                    subdivisions = 2000L)$value)

## check: maximum absolute difference between the priors given a = 5 and a = Inf
x <- seq(0.01, 4, length.out = 400)
print(c(default      = max(abs(pc_ls(x, theta_l_def, d_ls_5) - pc_ls(x, theta_l_def, d_ls_inf))),
        concentrated = max(abs(pc_ls(x, theta_l_con, d_ls_5) - pc_ls(x, theta_l_con, d_ls_inf)))))

p2 <- ggplot(prior_ls, aes(ls, density, linetype = theta)) +
  geom_line(linewidth = 0.6) +
  scale_linetype_manual(values = c(default = "solid", concentrated = "dashed"),
                        breaks = c("default", "concentrated"),
                        labels = expression(theta[lambda] == "1.66", theta[lambda] == "3.48"),
                        name = NULL) +
  scale_x_continuous(breaks = seq(-4, 4, 2)) +
  labs(x = expression(lambda^"*"), y = NULL, title = expression("Prior for" ~ lambda^"*" ~ "given" ~ a == infinity)) +
  theme_paper() +
  theme(legend.key.width = unit(0.7, "cm")) +
  guides(linetype = guide_legend(nrow = 2))

## ---------------------------------------------------------------------
## Right panel: joint prior pi_PC(a) pi_PC(lambda* | a), default setting
## ---------------------------------------------------------------------
a_joint  <- exp(seq(log(2.2), log(60), length.out = 70))
ls_joint <- seq(-5, 5, length.out = 201)
joint <- do.call(rbind, lapply(a_joint, function(a) {
  dfun <- make_d_ls(a, ls_max = 50, n = 200)
  data.frame(a = a, ls = ls_joint,
             logdens = log(pc_a(a, theta_a_def)) +
               log(pc_ls(ls_joint, theta_l_def, dfun)))
}))

p3 <- ggplot(joint, aes(a, ls, z = logdens)) +
  geom_raster(aes(fill = logdens), interpolate = TRUE) +
  geom_contour(colour = "white", linewidth = 0.25, bins = 12) +
  scale_fill_viridis_c(name = NULL) +
  scale_x_log10(expand = c(0, 0), breaks = c(3, 5, 10, 20, 50)) +
  scale_y_continuous(expand = c(0, 0)) +
  labs(x = "a (log scale)", y = expression(lambda^"*"),
       title = "Log joint prior density") +
  theme_paper() +
  theme(legend.key.width = unit(0.8, "cm"), legend.key.height = unit(0.3, "cm"),
        plot.margin = margin(5.5, 12, 5.5, 5.5))

fig2 <- p1 + p2 + p3 + plot_layout(widths = c(1, 1, 1))
ggsave("figures/pc_priors.pdf", fig2, width = fig_width, height = 3.6)
