## =====================================================================
## Section 7.1: download the IMD 0.25-degree daily gridded rainfall data,
## 1901-2025, one NetCDF file per year, into data/imd_raw/
## Source: https://www.imdpune.gov.in/cmpg/Griddata/Rainfall_25_NetCDF.html
## (Pai et al., 2014, Mausam 65:1-18)
##
## If the automatic download fails (the IMD site changes its download form from
## time to time), download the yearly files by hand from the page above and put
## them in data/imd_raw/ with the year in the file name (e.g. RF25_ind1901_rfp25.nc).
## Files already present are not downloaded again.
## Run: Rscript scripts/07_data_download.R      Package: httr
## =====================================================================

library(httr)

years   <- 1901:2025
raw_dir <- "data/imd_raw"
dir.create(raw_dir, recursive = TRUE, showWarnings = FALSE)

## ------------------------- Step 1: download ---------------------------
is_netcdf <- function(f) {
  if (!file.exists(f) || file.size(f) < 1e4) return(FALSE)
  magic <- readBin(f, "raw", 4)
  identical(magic[1:3], charToRaw("CDF")) ||
    identical(magic, as.raw(c(0x89, 0x48, 0x44, 0x46)))       # classic or HDF5-based
}
find_file <- function(y) {
  f <- list.files(raw_dir, pattern = paste0(y, ".*\\.nc$"), full.names = TRUE)
  f <- f[vapply(f, is_netcdf, logical(1))]
  if (length(f)) f[1] else NA_character_
}
download_year <- function(y) {
  dest <- file.path(raw_dir, sprintf("RF25_ind%d_rfp25.nc", y))
  ## The download form posts the selected year to RF25.php
  r <- tryCatch(POST("https://www.imdpune.gov.in/cmpg/Griddata/RF25.php",
                     body = list(RF25 = as.character(y)), encode = "form",
                     write_disk(dest, overwrite = TRUE), timeout(600)),
                error = function(e) NULL)
  if (is.null(r) || !is_netcdf(dest)) { unlink(dest); return(FALSE) }
  TRUE
}
for (y in years) {
  if (!is.na(find_file(y))) next
  cat("Downloading", y, "... ")
  cat(if (download_year(y)) "ok\n" else "FAILED (download by hand, see header)\n")
}
missing <- years[is.na(vapply(years, find_file, character(1)))]
if (length(missing)) stop("Missing years: ", paste(missing, collapse = ", "))
cat("All", length(years), "yearly files are in", raw_dir, "\n")
