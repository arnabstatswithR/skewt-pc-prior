## =====================================================================
## Section 7: per-cell fits to summer monsoon (JJAS) rainfall totals, 1901-2025
##
## At each retained land cell, six semiparametric models with the same B-spline
## location in year (the four error distributions of the simulation study, and
## the skew-t model under two conventional priors):
##   gauss - Gaussian
##   t     - Student-t (lambda = 0), PC prior on a
##   sn    - skew-normal (a = Inf), PC prior on lambda*
##   st    - skew-t, joint PC prior (proposed)
##   st_hrs - skew-t, priors of Hazra et al. (2020): lambda ~ N(0, 10^2), a ~ U(0.1, 20)
##   st_js  - skew-t, lambda ~ N(0, 10^2), a ~ Gamma(2, 0.1) (Juarez and Steel 2010)
##
## The response is modeled on the scale given by 'transform' (default: square
## root, so that the fitted distribution puts negligible mass below zero);
## WAIC/DIC, trends and Pr(Y < 0) refer to that scale, quantiles are on the mm scale.
##
## Run after scripts/09_data_long.R:   Rscript scripts/11_application_fit.R
## Results are saved in chunks to results/app/ so that the run can be stopped
## and restarted; at the end, all cells are combined into results/app_results.csv
## (results/app_1951_results.csv for the sensitivity run with year_min = 1951).
## Packages: sn, splines, parallel
## =====================================================================

## One BLAS thread per worker: the matrices are tiny, and multithreaded BLAS in
## 60+ forked workers would oversubscribe the machine
Sys.setenv(OMP_NUM_THREADS = 1, OPENBLAS_NUM_THREADS = 1, MKL_NUM_THREADS = 1)
if (requireNamespace("RhpcBLASctl", quietly = TRUE)) {
  RhpcBLASctl::blas_set_num_threads(1); RhpcBLASctl::omp_set_num_threads(1)
}

source("R/pc_prior_functions.R")
source("R/skewt_mcmc.R")
library(sn)
library(parallel)

## ------------------------- user settings ------------------------------
K       <- 12                         # B-splines for the location (about one per decade for 1901-2025)
mcmc    <- list(n_iter = 20000, n_burn = 10000, thin = 10)   # 1000 retained draws
probs   <- c(0.1, 0.9)                # quantiles: dry and wet seasons recurring once in ten years
n_qdraw <- 200                        # draws used for the quantiles
n_cores <- max(1, detectCores() - 1)  # 23 on the 24-thread workstation
chunk   <- 8 * n_cores                # cells per saved file (multiple of n_cores: no idle tail)
test_cells <- NULL                    # e.g. 1:20 for a trial run; NULL = all cells
test_random <- FALSE                  # TRUE: use 'test_cells' as a count of randomly chosen cells
transform <- "sqrt"                   # response scale: "none", "sqrt", "cbrt" (cube root) or "log1p"
year_min <- 1901                      # first year; 1951 for the sensitivity analysis
out_dir <- if (year_min == 1901) "results/app" else paste0("results/app_", year_min)
max_sec <- 1800                       # time limit per cell (s); generous: a normal cell takes 2-5 min
## ----------------------------------------------------------------------

dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
grid <- build_ls_grid()
dat  <- read.csv("data/jjas_long.csv")
dat  <- dat[dat$year >= year_min, ]
if (year_min > 1901) K <- max(5, round(K * (2025 - year_min + 1) / 125))   # same knot spacing
cells <- sort(unique(dat$cell))
if (!is.null(test_cells)) {
  if (test_random) {
    n_test <- if (length(test_cells) > 1) length(test_cells) else as.integer(test_cells)
    set.seed(1); cells <- sort(sample(cells, n_test))
  } else cells <- cells[test_cells]
}
tf  <- switch(transform, none = identity, sqrt = sqrt, cbrt = function(x) x^(1/3), log1p = log1p)
itf <- switch(transform, none = identity, sqrt = function(x) pmax(x, 0)^2,
              cbrt = function(x) pmax(x, 0)^3, log1p = expm1)
years <- sort(unique(dat$year))
B <- bspline_basis(years, K)
yr_end <- c(1, length(years))         # rows for 1901 and 2025

## ------------------------- helpers ------------------------------------
gaussian_mcmc <- function(y, B, n_iter, n_burn, thin) {     # conjugate Gibbs, standardized scale
  n <- length(y); Kb <- ncol(B); yc <- mean(y); ys <- sd(y); z <- (y - yc) / ys
  v_one <- as.numeric(qr.coef(qr(B), rep(1, n))); v_one[is.na(v_one)] <- 0
  BtB <- crossprod(B); Btz <- crossprod(B, z); s2 <- 1
  keep <- seq(n_burn + thin, n_iter, by = thin)
  bo <- matrix(NA_real_, length(keep), Kb); so <- numeric(length(keep)); r <- 0
  for (it in 1:n_iter) {
    R <- chol(BtB / s2 + diag(1 / 100, Kb))
    beta <- as.numeric(backsolve(R, forwardsolve(t(R), Btz / s2)) + backsolve(R, rnorm(Kb)))
    s2 <- 1 / rgamma(1, 0.01 + n / 2, 0.01 + sum((z - B %*% beta)^2) / 2)
    if (it %in% keep) { r <- r + 1; bo[r, ] <- beta; so[r] <- s2 }
  }
  bo <- sweep(ys * bo, 2, yc * v_one, "+"); sd <- ys * sqrt(so)
  mu <- bo %*% t(B)
  list(mu = mu, sd = sd, loglik = dnorm(matrix(y, nrow(mu), n, byrow = TRUE), mu, sd, log = TRUE))
}

ic_from_ll <- function(ll, ll_hat) {  # ll: draws x n; ll_hat: log lik at posterior mean
  ok <- is.finite(rowSums(ll))
  ll <- ll[ok, , drop = FALSE]
  dev <- -2 * rowSums(ll); p_d <- mean(dev) + 2 * ll_hat
  c(WAIC = waic(ll)[["WAIC"]], DIC = mean(dev) + p_d, p_D = p_d, frac_outside = mean(!ok))
}

fit_st <- function(y, family = "st", prior = "pc") {
  f <- do.call(skewt_mcmc, c(list(y = y, B = B, prior = prior, family = family, grid = grid,
                                  beta_block = TRUE, verbose = FALSE), mcmc))
  S <- f$samples
  bh <- colMeans(S[, 1:K, drop = FALSE])
  a_hat <- if (family == "sn") Inf else mean(S[, "a"])
  ll_hat <- sum(dst_log(y, as.numeric(B %*% bh), mean(S[, "lambda"]), a_hat, mean(S[, "b"])))
  mu_end <- S[, 1:K, drop = FALSE] %*% t(B[yr_end, , drop = FALSE])
  idx <- round(seq(1, nrow(S), length.out = n_qdraw))
  q_err <- function(p, l, a, b) if (is.infinite(a)) qsn(p, 0, sqrt(b + l^2), l / sqrt(b)) else
    qst(p, 0, sqrt(b + l^2), l / sqrt(b), a)
  q <- lapply(probs, function(p)
    mu_end[idx, ] + mapply(q_err, p, S[idx, "lambda"], S[idx, "a"], S[idx, "b"]))   # draws x 2 each
  out <- list(ic = ic_from_ll(f$loglik, ll_hat), q = q,
              trend = mu_end[, 2] - mu_end[, 1], acc = f$acceptance)
  if (family == "st") {
    tau <- 1 / S[, "a"]; ls <- S[, "lambda_star"]
    out$par <- c(tau_mean = mean(tau), tau_q025 = quantile(tau, 0.025, names = FALSE),
                 tau_q975 = quantile(tau, 0.975, names = FALSE),
                 pr_a_gt_30 = mean(S[, "a"] > 30),
                 ls_mean = mean(ls), ls_q025 = quantile(ls, 0.025, names = FALSE),
                 ls_q975 = quantile(ls, 0.975, names = FALSE),
                 pr_neg = mean(mapply(function(m, l, a, b) pst(0, m, sqrt(b + l^2), l / sqrt(b), a),
                                      mu_end[idx, 1], S[idx, "lambda"], S[idx, "a"], S[idx, "b"])))
  }
  out
}

summ_draws <- function(x) c(mean = mean(x), q025 = quantile(x, 0.025, names = FALSE),
                            q975 = quantile(x, 0.975, names = FALSE))

trend_cols <- function(x, nm) c(setNames(summ_draws(x), paste0("trend_", nm, "_", c("mean", "q025", "q975"))),
                                setNames(mean(x > 0), paste0("pr_increase_", nm)))
q_cols <- function(q, nm) unlist(lapply(seq_along(probs), function(k) {
  x <- q[[k]]
  setNames(c(summ_draws(x[, 1]), summ_draws(x[, 2]), summ_draws(x[, 2] - x[, 1])),
           paste0("q", round(100 * probs[k]), "_", nm, "_", rep(c("1901", "2025", "diff"), each = 3), "_",
                  c("mean", "q025", "q975")))
}))

fit_cell <- function(cl) {
  d <- dat[dat$cell == cl, ]; d <- d[order(d$year), ]; y <- tf(d$y)
  set.seed(cl)
  t0 <- proc.time()[["elapsed"]]
  st <- fit_st(y, "st");  t_st <- proc.time()[["elapsed"]] - t0
  tt <- fit_st(y, "t")
  sn <- fit_st(y, "sn")
  hrs <- fit_st(y, "st", "hrs")       # skew-t, priors of Hazra et al. (2020)
  js  <- fit_st(y, "st", "js")        # skew-t, Gamma(2, 0.1) prior on a (Juarez and Steel 2010)
  g  <- gaussian_mcmc(y, B, mcmc$n_iter, mcmc$n_burn, mcmc$thin)
  g_hat <- sum(dnorm(y, colMeans(g$mu), mean(g$sd), log = TRUE))
  g_q <- lapply(probs, function(p) (g$mu + qnorm(p) * g$sd)[, yr_end])
  ## quantiles back on the mm scale (quantiles are equivariant under monotone maps)
  bt <- function(f) lapply(f, itf)
  g_q <- bt(g_q); tt$q <- bt(tt$q); sn$q <- bt(sn$q); st$q <- bt(st$q); hrs$q <- bt(hrs$q); js$q <- bt(js$q)
  ic <- rbind(gauss = ic_from_ll(g$loglik, g_hat), t = tt$ic, sn = sn$ic, st = st$ic,
              st_hrs = hrs$ic, st_js = js$ic)
  data.frame(cell = cl, lon = d$lon[1], lat = d$lat[1],
             t(setNames(as.vector(t(ic)), paste(rep(rownames(ic), each = 4), colnames(ic), sep = "_"))),
             t(st$par),
             t(setNames(hrs$par, paste0(names(hrs$par), "_hrs"))),
             t(setNames(js$par,  paste0(names(js$par),  "_js"))),
             t(trend_cols(g$mu[, yr_end[2]] - g$mu[, yr_end[1]], "gauss")),
             t(trend_cols(tt$trend, "t")), t(trend_cols(sn$trend, "sn")), t(trend_cols(st$trend, "st")),
             t(trend_cols(hrs$trend, "st_hrs")), t(trend_cols(js$trend, "st_js")),
             t(q_cols(g_q, "gauss")), t(q_cols(tt$q, "t")), t(q_cols(sn$q, "sn")), t(q_cols(st$q, "st")),
             t(q_cols(hrs$q, "st_hrs")), t(q_cols(js$q, "st_js")),
             acc_a = st$acc[["log_a"]], acc_lambda = st$acc[["lambda"]],
             time_st = t_st, check.names = FALSE)
}

## Wrapper: time limit per cell, and a log of started/finished cells so that a
## cell that hangs can be identified (results/app/progress.log)
log_file <- file.path(out_dir, "progress.log")
fit_cell_safe <- function(cl) {
  cat(sprintf("%s start %d\n", format(Sys.time(), "%H:%M:%S"), cl), file = log_file, append = TRUE)
  setTimeLimit(elapsed = max_sec, transient = TRUE)
  on.exit(setTimeLimit(elapsed = Inf))
  out <- tryCatch(fit_cell(cl), error = function(e) paste("cell", cl, ":", conditionMessage(e)))
  cat(sprintf("%s %s %d\n", format(Sys.time(), "%H:%M:%S"),
              if (is.data.frame(out)) "done " else "FAIL ", cl), file = log_file, append = TRUE)
  out
}

## ------------------------- main loop over chunks ----------------------
chunks <- split(cells, ceiling(seq_along(cells) / chunk))
cat(length(cells), "cells in", length(chunks), "chunks;", n_cores, "cores\n")
for (j in seq_along(chunks)) {
  file <- file.path(out_dir, sprintf("app_chunk%03d.rds", j))
  if (file.exists(file)) next
  t0 <- Sys.time()
  res <- mclapply(chunks[[j]], fit_cell_safe, mc.cores = n_cores, mc.preschedule = FALSE)
  ok <- vapply(res, is.data.frame, logical(1))
  if (any(!ok)) cat("  ", sum(!ok), "cells failed; first error:",
                    if (is.null(res[!ok][[1]])) "worker crashed (no result)" else as.character(res[!ok][[1]])[1], "\n")
  if (any(ok)) saveRDS(do.call(rbind, res[ok]), file)
  cat(sprintf("chunk %d/%d done in %.1f min\n", j, length(chunks),
              as.numeric(difftime(Sys.time(), t0, units = "mins"))))
}

## ------------------------- refit cells that were lost -----------------
## A worker that crashes (e.g. out of memory) makes mclapply return NULL for
## all cells assigned to it. Refit those cells one at a time per core.
done_cells <- unlist(lapply(list.files(out_dir, "^app_.*\\.rds$", full.names = TRUE),
                            function(f) readRDS(f)$cell))
lost <- setdiff(cells, done_cells)
if (length(lost)) {
  cat(length(lost), "cells missing; refitting\n")
  res <- mclapply(lost, fit_cell_safe, mc.cores = n_cores, mc.preschedule = FALSE)
  ok <- vapply(res, is.data.frame, logical(1))
  if (any(!ok)) {
    cat(sum(!ok), "cells still failed:\n")
    print(data.frame(cell = lost[!ok], error = vapply(res[!ok], function(x)
      if (is.null(x)) "worker crashed (no result)" else as.character(x)[1], character(1))))
  }
  if (any(ok)) saveRDS(do.call(rbind, res[ok]),
                       file.path(out_dir, sprintf("app_refit_%s.rds", format(Sys.time(), "%Y%m%d%H%M"))))
}

## ------------------------- combine all cells into one CSV --------------
f <- list.files(out_dir, "^app_.*\\.rds$", full.names = TRUE)
res_all <- do.call(rbind, lapply(f, readRDS)); res_all <- res_all[!duplicated(res_all$cell), ]
csv <- if (year_min == 1901) "results/app_results.csv" else sprintf("results/app_%d_results.csv", year_min)
write.csv(res_all, csv, row.names = FALSE)
cat("Saved", csv, "with", nrow(res_all), "cells\n")
cat("Done.\n")
