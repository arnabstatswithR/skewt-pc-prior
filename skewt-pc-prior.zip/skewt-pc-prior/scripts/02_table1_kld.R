## =====================================================================
## Table: KLD(lambda_star | a) between the skew-t and Student-t
## distributions (Theorem 4.2), and a numerical check of monotonicity in a
##
## Uses the representation
##   KLD(ls | a) = log 2 - E[ H{ u_ls(|Z|) } ],  Z ~ t_a,
##   u_ls(z) = T_{a+1}( ls * z * sqrt((a + 1) / (a + z^2)) ),
##   H(u) = -u log u - (1 - u) log(1 - u),
## i.e. KLD(ls | a) = int_0^Inf 2 t_a(z) [log 2 - H{u_ls(z)}] dz.
## a = Inf gives the skew-normal case.
## Base R only.
## =====================================================================

binary_entropy <- function(u) {
  u <- pmin(pmax(u, 1e-300), 1 - 1e-16)
  -u * log(u) - (1 - u) * log1p(-u)
}

kld_st_t <- function(ls, a) {
  if (is.infinite(a)) {
    integrand <- function(z) 2 * dnorm(z) * (log(2) - binary_entropy(pnorm(ls * z)))
  } else {
    integrand <- function(z) {
      u <- pt(ls * z * sqrt((a + 1) / (a + z^2)), df = a + 1)
      2 * dt(z, df = a) * (log(2) - binary_entropy(u))
    }
  }
  integrate(integrand, 0, Inf, rel.tol = 1e-10, subdivisions = 1000L)$value
}

## ---- Panel (a) of Table 1 (printed with lambda_star in rows) -------
a_vals  <- c(3, 5, 10, 30, Inf)
ls_vals <- c(0.5, 1, 2, 3, 5, 10)

tab <- outer(ls_vals, a_vals, Vectorize(kld_st_t))
dimnames(tab) <- list(lambda_star = ls_vals,
                      a = c(head(a_vals, -1), "Inf (skew-normal)"))
print(round(tab, 3))

## LaTeX rows, ready to paste into the manuscript
cat(sprintf("%-4s & %s\\\\\n", ls_vals,
            apply(tab, 1, function(r) paste(sprintf("%.3f", r), collapse = " & "))),
    sep = "")

## ---- Numerical check: KLD increases in a for fixed lambda_star ------
a_grid  <- c(seq(2.05, 50, length.out = 120), Inf)
ls_grid <- seq(0.1, 20, length.out = 60)
violations <- 0
for (ls in ls_grid) {
  k <- sapply(a_grid, function(a) kld_st_t(ls, a))
  violations <- violations + sum(diff(k) < -1e-10)
}
cat("Number of decreases in a over the grid:", violations, "\n")  # expected: 0

## ---- Upper bound -----------------------------------------------------
cat("KLD(1000 | 5) =", kld_st_t(1000, 5), "; log 2 =", log(2), "\n")

## =====================================================================
## Remark 4.5: reverse ordering. Divergence between the skew-t and the
## skew-normal with the same lambda_star, both standardized to zero mean
## and unit variance (requires a > 2).
## =====================================================================
c_a <- function(a) sqrt(a / pi) * exp(lgamma((a - 1) / 2) - lgamma(a / 2))

dst_std <- function(y, a, ls) {           # standardized skew-t density
  d <- ls / sqrt(1 + ls^2); m <- c_a(a) * d; v <- a / (a - 2) - m^2
  x <- m + sqrt(v) * y
  sqrt(v) * 2 * dt(x, a) * pt(ls * x * sqrt((a + 1) / (a + x^2)), a + 1)
}
dsn_std <- function(y, ls) {              # standardized skew-normal density
  d <- ls / sqrt(1 + ls^2); m <- sqrt(2 / pi) * d; v <- 1 - m^2
  x <- m + sqrt(v) * y
  sqrt(v) * 2 * dnorm(x) * pnorm(ls * x)
}
kld_st_sn <- function(a, ls) {
  h <- function(y) {
    f <- dst_std(y, a, ls); g <- dsn_std(y, ls)
    ifelse(f > 0, f * (log(pmax(f, 1e-300)) - log(pmax(g, 1e-300))), 0)
  }
  cuts <- c(-Inf, -5, 0, 5, Inf)
  sum(sapply(1:4, function(k)
    integrate(h, cuts[k], cuts[k + 1], rel.tol = 1e-10, subdivisions = 1000L)$value))
}
ls_cols <- c(0, 0.5, 1, 2, 3, 5, 10)
rev_tab <- outer(c(3, 5, 10, 30), ls_cols, Vectorize(function(a, ls) kld_st_sn(a, ls)))
dimnames(rev_tab) <- list(a = c(3, 5, 10, 30), lambda_star = ls_cols)
print(round(rev_tab, 3))   # Panel (b) of Table 1; the row a = Inf is identically 0
