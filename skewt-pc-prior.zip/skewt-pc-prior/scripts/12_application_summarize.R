## =====================================================================
## Section 7: summaries and figures from the per-cell fits
##
## Input:  results/app_results.csv (combined output of scripts/11_application_fit.R)
##         data/jjas_long.csv      (to count zero seasons per cell)
## Cells with a JJAS total of exactly zero in more than 25% of the years are
## excluded here (outside the effective coverage of the gauge network); cells
## are matched by longitude and latitude.
##
## Output: console summaries (numbers quoted in Section 7)
##         figures/jjas_map.pdf        mean and SD of the JJAS totals
##         figures/app_comparison.pdf  WAIC difference to the Gaussian model; best model
##         figures/app_prior.pdf       lambda* under the three priors; Pr(a > 30)
##         figures/app_tails.pdf       tau = 1/a; Pr(Y < 0)
##         figures/app_trends.pdf      location change, Pr(increase), change in q10 and q90
##         results/app_table_rows.tex  rows of the model-comparison table
## Run: Rscript scripts/12_application_summarize.R
## Packages: ggplot2, patchwork, scales; for the Google basemap also ggmap and mapproj
## =====================================================================

source("R/theme_paper.R")
library(ggplot2)
library(patchwork)

zero_max <- 0.25            # exclude cells with zero JJAS totals in more than this share of years
basemap  <- "google"        # "google" (needs ggmap and an API key) or "none"
tile_alpha <- 1             # opacity of the cells; e.g. 0.8 lets the relief show through
## The key is read from an environment variable, so that it never appears in the
## script: put  GGMAP_GOOGLE_API_KEY=your_key  in ~/.Renviron and restart R.

r <- read.csv("results/app_results.csv")
r <- r[!duplicated(r$cell), ]
dat <- read.csv("data/jjas_long.csv")
nz <- aggregate(y ~ lon + lat, dat, function(z) c(n_zero = sum(z == 0), n = length(z)))
nz <- data.frame(lon = nz$lon, lat = nz$lat, n_zero = nz$y[, "n_zero"], n_years = nz$y[, "n"])
r <- merge(r, nz, by = c("lon", "lat"), all.x = TRUE)
excl <- r$n_zero > zero_max * r$n_years
cat("Cells fitted:", nrow(r), "| excluded (zero JJAS total in more than", 100 * zero_max,
    "% of years):", sum(excl), "| analyzed:", sum(!excl), "\n")
cat("  (cells with zero totals in more than 50% of years were already removed before fitting)\n")
r <- r[!excl, ]

M  <- c(gauss = "Gaussian", t = "Student-t", sn = "Skew-normal", st = "Skew-t (PC, proposed)",
        st_hrs = "Skew-t (HRS prior)", st_js = "Skew-t (Gamma prior)")
W  <- as.matrix(r[, paste0(names(M), "_WAIC")]); colnames(W) <- names(M)
D  <- as.matrix(r[, paste0(names(M), "_DIC")]);  colnames(D) <- names(M)

## ------------------------- model comparison ---------------------------
best_w <- names(M)[apply(W, 1, which.min)]
best_d <- names(M)[apply(D, 1, which.min)]
tab <- data.frame(model = M,
                  WAIC = colMeans(W), DIC = colMeans(D),
                  pD = colMeans(r[, paste0(names(M), "_p_D")]),
                  best_WAIC = as.numeric(table(factor(best_w, names(M)))) / nrow(r),
                  best_DIC  = as.numeric(table(factor(best_d, names(M)))) / nrow(r))
dW <- W[, "st"] - W                                     # proposed minus competitor
tab$st_better2 <- colMeans(dW < -2); tab$st_worse2 <- colMeans(dW > 2)
tab$dW_q05 <- apply(dW, 2, quantile, 0.05); tab$dW_q95 <- apply(dW, 2, quantile, 0.95)
cat("\nModel comparison (WAIC/DIC means over cells; shares of cells; dW = WAIC(proposed) - WAIC(model)):\n")
print(format(tab, digits = 3), row.names = FALSE)

fmt <- function(x, d = 1) formatC(x, format = "f", digits = d)
rows <- with(tab, paste0(model, " & ", fmt(WAIC), " & ", fmt(DIC), " & ", fmt(pD), " & ",
                         fmt(best_WAIC, 3), " & ",
                         ifelse(rownames(tab) == "st", "--", fmt(st_better2, 3)), " & ",
                         ifelse(rownames(tab) == "st", "--", fmt(st_worse2, 3)), "\\\\"))
rows <- gsub("Skew-t", "Skew-$t$", gsub("Student-t", "Student-$t$", rows))
writeLines(rows, "results/app_table_rows.tex")

## Regions (rough boxes, for summaries only)
reg <- with(r, ifelse(lat >= 32, "Jammu and Kashmir, Ladakh",
           ifelse(lon < 73 & lat >= 22 & lat < 30, "Arid northwest",
           ifelse(lon >= 89 & lat >= 21, "Northeast",
           ifelse(lon >= 73.5 & lon <= 77 & lat <= 21, "West coast and Western Ghats", "Rest of India")))))
cat("\nBy region (means):\n")
print(round(sapply(split(data.frame(dW_gauss = dW[, "gauss"], dW_hrs = dW[, "st_hrs"], dW_js = dW[, "st_js"],
                                    tau = r$tau_mean, ls_pc = r$ls_mean, ls_hrs = r$ls_mean_hrs,
                                    pr_a30 = r$pr_a_gt_30, pr_neg = r$pr_neg), reg), colMeans), 3))
print(table(reg))

## ------------------------- effect of the prior ------------------------
cat("\nPrior comparison for the skew-t model:\n")
for (s in c("", "_hrs", "_js")) {
  cat(sprintf("%-5s |lambda*|<0.5: %.3f | CI for lambda* excludes 0: %.3f | mean tau: %.3f | mean Pr(a>30): %.3f\n",
              ifelse(s == "", "PC", sub("_", "", s)),
              mean(abs(r[[paste0("ls_mean", s)]]) < 0.5),
              mean(r[[paste0("ls_q025", s)]] > 0 | r[[paste0("ls_q975", s)]] < 0),
              mean(r[[paste0("tau_mean", s)]]), mean(r[[paste0("pr_a_gt_30", s)]])))
}
cat(sprintf("PC prior has lower WAIC than the HRS prior in %.3f and than the Gamma prior in %.3f of cells\n",
            mean(dW[, "st_hrs"] < 0), mean(dW[, "st_js"] < 0)))
cat("\nPr(Y < 0) under the proposed model: share of cells below 0.001, 0.01, 0.05:",
    round(c(mean(r$pr_neg < 0.001), mean(r$pr_neg < 0.01), mean(r$pr_neg < 0.05)), 3), "\n")

## ------------------------- trends -------------------------------------
cat("\nTrend in the location (square-root scale), proposed vs Gaussian: correlation",
    round(cor(r$trend_st_mean, r$trend_gauss_mean), 3), "| median ratio of CI widths",
    round(median((r$trend_st_q975 - r$trend_st_q025) / (r$trend_gauss_q975 - r$trend_gauss_q025)), 3),
    "| share of cells with narrower CI", round(mean((r$trend_st_q975 - r$trend_st_q025) <
                                                     (r$trend_gauss_q975 - r$trend_gauss_q025)), 3), "\n")
cat("Pr(increase) > 0.95:", round(mean(r$pr_increase_st > 0.95), 3),
    "| < 0.05:", round(mean(r$pr_increase_st < 0.05), 3), "\n")
print(round(sapply(split(data.frame(inc = r$pr_increase_st > 0.95, dec = r$pr_increase_st < 0.05), reg), colMeans), 3))
cat("Change 1901-2025 in the 0.1 and 0.9 quantiles (mm), proposed model: medians",
    round(median(r$q10_st_diff_mean)), "and", round(median(r$q90_st_diff_mean)),
    "| CI above zero:", round(mean(r$q10_st_diff_q025 > 0), 3), round(mean(r$q90_st_diff_q025 > 0), 3),
    "| CI below zero:", round(mean(r$q10_st_diff_q975 < 0), 3), round(mean(r$q90_st_diff_q975 < 0), 3), "\n")

## ------------------------- figures ------------------------------------
if (basemap == "google") {
  library(ggmap)
  key <- Sys.getenv("GGMAP_GOOGLE_API_KEY")
  if (!nzchar(key)) stop("Set GGMAP_GOOGLE_API_KEY in ~/.Renviron (or use basemap <- \"none\").")
  register_google(key = key)
  ## Terrain basemap in color (relief shading, pale water, thin country borders);
  ## labels, roads, state boundaries and points of interest are removed so that
  ## the colored cells remain readable. Fetched once and reused for every panel.
  gstyle <- paste(c("feature:all|element:labels|visibility:off",
                    "feature:road|visibility:off",
                    "feature:poi|visibility:off",
                    "feature:transit|visibility:off",
                    "feature:administrative.province|visibility:off",
                    "feature:water|color:0xdcebf7",
                    "feature:administrative.country|element:geometry.stroke|color:0x555555|weight:0.8"),
                  collapse = "&style=")
  gmap <- get_googlemap(center = c(lon = 82.75, lat = 22.75), zoom = 4, scale = 2,
                        maptype = "terrain", color = "color", style = gstyle)
  ## Google tiles are in the Mercator projection, so keep ggmap's Mercator coordinates
  ## (package mapproj) and only restrict the extent to India
  gbase <- suppressMessages(ggmap(gmap) + coord_map("mercator", xlim = c(67.5, 98), ylim = c(7.5, 37.5)))
}
base <- function(p, ttl) {
  lay <- geom_tile(width = 0.25, height = 0.25, alpha = 1)
  q <- if (basemap == "google") {
    gbase + geom_tile(data = p$data, mapping = p$mapping, width = 0.25, height = 0.25,
                      alpha = tile_alpha, inherit.aes = FALSE) +
      labs(caption = "Map data \u00a9 Google")
  } else p + lay + coord_equal()
  ## Figures are saved 7.5 inches wide and shrunk to the text width (about 5.2
  ## inches) in the paper, so the font sizes below appear at about 70%
  q + labs(title = ttl, x = "Longitude", y = "Latitude", fill = NULL) +
    scale_x_continuous(labels = function(x) paste0(x, "\u00b0E")) +
    scale_y_continuous(labels = function(x) paste0(x, "\u00b0N")) +
    theme_paper() +
    theme(legend.position = "bottom", legend.direction = "horizontal",
          legend.key.width = unit(1.5, "cm"), legend.key.height = unit(0.35, "cm"),
          legend.margin = margin(0, 0, 0, 0), plot.margin = margin(4, 6, 2, 4))
}
div <- function(lim, rev = FALSE) scale_fill_gradient2(
  low = if (rev) "#b2182b" else "#2166ac", mid = "white", high = if (rev) "#2166ac" else "#b2182b",
  limits = c(-lim, lim), oob = scales::squish)
mp <- function(v, ttl, sc) base(ggplot(r, aes(lon, lat, fill = v)), ttl) + sc

## Data: mean and SD of the JJAS totals (same basemap as the other figures)
ms <- aggregate(y ~ lon + lat, dat, function(z) c(mean = mean(z), sd = sd(z)))
ms <- data.frame(lon = ms$lon, lat = ms$lat, mean = ms$y[, "mean"], sd = ms$y[, "sd"])
ms <- merge(ms, r[, c("lon", "lat")], by = c("lon", "lat"))       # analyzed cells only
mpd <- function(v, ttl) base(ggplot(ms, aes(lon, lat, fill = v)), ttl) +
  scale_fill_viridis_c(name = NULL, trans = "log10")
ggsave("figures/jjas_map.pdf", mpd(ms$mean, "Mean JJAS total (mm)") + mpd(ms$sd, "SD of JJAS total (mm)"),
       width = fig_width, height = 5.0)

## Model comparison
r$best4 <- factor(c(gauss = "Gaussian", t = "Student-t", sn = "Skew-normal", st = "Skew-t")
                  [colnames(W)[apply(W[, c("gauss", "t", "sn", "st")], 1, which.min)]],
                  levels = c("Gaussian", "Student-t", "Skew-normal", "Skew-t"))
f1 <- mp(dW[, "gauss"], "WAIC difference to Gaussian", div(10)) +
  mp(r$best4, "Model with lowest WAIC", list(scale_fill_manual(values = c("grey75", "#1b9e77", "#7570b3", "#d95f02")),
          guides(fill = guide_legend(nrow = 2)), theme(legend.key.width = unit(0.5, "cm"))))
ggsave("figures/app_comparison.pdf", f1, width = fig_width, height = 5.0)

## Effect of the prior
lim_ls <- quantile(abs(c(r$ls_mean, r$ls_mean_hrs, r$ls_mean_js)), 0.98)
f2 <- (mp(r$ls_mean, expression(lambda^"*" ~ "(PC prior)"), div(lim_ls)) +
       mp(r$ls_mean_hrs, expression(lambda^"*" ~ "(HRS prior)"), div(lim_ls))) /
      (mp(r$ls_mean_js, expression(lambda^"*" ~ "(Gamma prior)"), div(lim_ls)) +
       mp(r$pr_a_gt_30, expression(Pr(a > 30 ~ "|" ~ data)), scale_fill_viridis_c(limits = c(0, 1))))
ggsave("figures/app_prior.pdf", f2, width = fig_width, height = 9.4)

## Tails and support
f3 <- mp(r$tau_mean, expression(tau == 1/a ~ "(PC prior)"), scale_fill_viridis_c()) +
  mp(pmax(r$pr_neg, 1e-6), expression(Pr(Y < 0)), scale_fill_viridis_c(trans = "log10", limits = c(1e-6, 1),
                                                                     oob = scales::squish))
ggsave("figures/app_tails.pdf", f3, width = fig_width, height = 5.0)

## Trends and seasonal quantiles
lim_q <- quantile(abs(c(r$q10_st_diff_mean, r$q90_st_diff_mean)), 0.95)
f4 <- (mp(r$trend_st_mean, "Change in location (sqrt scale)", div(quantile(abs(r$trend_st_mean), 0.95), rev = TRUE)) +
       mp(r$pr_increase_st, "Pr(increase | data)", scale_fill_gradient2(low = "#b2182b", mid = "white", high = "#2166ac",
                                                                         midpoint = 0.5, limits = c(0, 1)))) /
      (mp(r$q10_st_diff_mean, "Change in 0.1 quantile (mm)", div(lim_q, rev = TRUE)) +
       mp(r$q90_st_diff_mean, "Change in 0.9 quantile (mm)", div(lim_q, rev = TRUE)))
ggsave("figures/app_trends.pdf", f4, width = fig_width, height = 9.4)
cat("\nSaved figures/jjas_map.pdf, app_comparison.pdf, app_prior.pdf, app_tails.pdf, app_trends.pdf and results/app_table_rows.tex\n")
