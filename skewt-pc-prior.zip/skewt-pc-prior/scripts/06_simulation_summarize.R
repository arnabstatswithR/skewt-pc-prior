## =====================================================================
## Section 6: simulation study -- summaries, tables, and figures
##
## Run after scripts/05_simulation_run.R:   Rscript scripts/06_simulation_summarize.R
## Output:
##   results/sim_summary.csv                    (all configurations)
##   results/sim_table_rows.tex                 (rows of Table 3, read by main.tex)
##   figures/sim_prior.pdf  (Fig. 3: coverage and bias, semiparametric fit)
##   figures/sim_model.pdf  (Fig. 4: fitting error and WAIC, PC prior)
## Packages: ggplot2, patchwork
## =====================================================================

source("R/theme_paper.R")
library(ggplot2)
library(patchwork)
dir.create("figures", showWarnings = FALSE)

files <- list.files("results/sim", pattern = "\\.rds$", full.names = TRUE)
all <- do.call(rbind, lapply(files, function(f) {
  x <- readRDS(f)
  if (is.null(x$results) || nrow(x$results) == 0) return(NULL)   # skip failed configurations
  cbind(x$config[rep(1, nrow(x$results)), ], x$results)
}))
truth_tab <- data.frame(truth = c("Gaussian", "Student-t", "Skew-normal", "Skew-t"),
                        tau_true = c(0, 1 / 5, 0, 1 / 5), ls_true = c(0, 0, 3, 3))
all <- merge(all, truth_tab, by = "truth")

## Coverage of 95% equal-tailed intervals; for tau, only when tau_true > 0
## (tau_true = 0 lies on the boundary, where an interval for tau > 0 cannot
## contain it). Bias is based on posterior medians, which are more stable than
## posterior means for lambda* when the skewness is weakly identified.
all$cover_tau <- ifelse(all$tau_true > 0,
                        all$tau_q025 <= all$tau_true & all$tau_true <= all$tau_q975, NA)
all$cover_ls  <- all$ls_q025 <= all$ls_true & all$ls_true <= all$ls_q975
all$abs_bias_tau <- abs(all$tau_median - all$tau_true)
all$abs_bias_ls  <- abs(all$ls_median - all$ls_true)

key <- c("n", "truth", "dgp", "fit", "prior")
summ <- aggregate(cbind(cover_tau, cover_ls, abs_bias_tau, abs_bias_ls, prob_a_gt_30,
                        fit_error, waic, dic, time, acc_a) ~ n + truth + dgp + fit + prior,
                  data = all, FUN = mean, na.action = na.pass)
summ$n_rep <- aggregate(rep ~ n + truth + dgp + fit + prior, data = all, FUN = length)$rep
write.csv(summ, "results/sim_summary.csv", row.names = FALSE)

prior_lab <- c(hrs = "Uniform (HRS 2020)", js = "Gamma(2, 0.1)",
               pc = "PC (default)", pc_conc = "PC (concentrated)")
truth_lev <- c("Gaussian", "Student-t", "Skew-normal", "Skew-t")

## ---------------------------------------------------------------------
## Table for the text: semiparametric fit, nonlinear location
## ---------------------------------------------------------------------
tab <- subset(summ, fit == "semiparametric" & dgp == "nonlinear")
tab <- tab[order(tab$n, match(tab$truth, truth_lev), match(tab$prior, names(prior_lab))), ]
fmt <- function(x, d = 3) ifelse(is.na(x), "--", formatC(x, format = "f", digits = d))
rows <- sprintf("%d & %s & %s & %s & %s & %s & %s & %s\\\\", tab$n, tab$truth,
                prior_lab[tab$prior], fmt(tab$cover_tau, 2), fmt(tab$cover_ls, 2),
                fmt(tab$abs_bias_tau), fmt(tab$abs_bias_ls), fmt(tab$prob_a_gt_30, 2))
## add a small gap between the n = 50 and n = 200 blocks
rows <- append(rows, "\\midrule", after = sum(tab$n == 50))
writeLines(rows, "results/sim_table_rows.tex")   # read by main.tex (Table 3)
cat("\nTable rows written to results/sim_table_rows.tex:\n"); cat(rows, sep = "\n")

## Computational cost (seconds per fit), by n and fitted model
cat("\nMean computing time per fit (seconds):\n")
print(aggregate(time ~ n + fit, data = summ, FUN = mean))

## ---------------------------------------------------------------------
## Figure 3: coverage and absolute bias, semiparametric fit, nonlinear location
## ---------------------------------------------------------------------
f3 <- subset(summ, fit == "semiparametric" & dgp == "nonlinear")
long <- rbind(
  data.frame(f3[, c("n", "truth", "prior")], measure = "Coverage",       parameter = "tau",
             value = f3$cover_tau),
  data.frame(f3[, c("n", "truth", "prior")], measure = "Coverage",       parameter = "lambda^'*'",
             value = f3$cover_ls),
  data.frame(f3[, c("n", "truth", "prior")], measure = "Absolute~bias",  parameter = "tau",
             value = f3$abs_bias_tau),
  data.frame(f3[, c("n", "truth", "prior")], measure = "Absolute~bias",  parameter = "lambda^'*'",
             value = f3$abs_bias_ls))
long$truth   <- factor(long$truth, levels = truth_lev)
long$prior   <- factor(prior_lab[long$prior], levels = prior_lab)
long$panel   <- factor(paste0(long$measure, "~(", long$parameter, ")"),
                       levels = c("Coverage~(tau)", "Coverage~(lambda^'*')",
                                  "Absolute~bias~(tau)", "Absolute~bias~(lambda^'*')"))
long$n_lab   <- factor(paste0("n == ", long$n), levels = c("n == 50", "n == 200"))
hline <- data.frame(panel = factor(c("Coverage~(tau)", "Coverage~(lambda^'*')"),
                                   levels = levels(long$panel)), y = 0.95)

p3 <- ggplot(subset(long, !is.na(value)),
             aes(truth, value, colour = prior, shape = prior, group = prior)) +
  geom_hline(data = hline, aes(yintercept = y), linetype = "dotted", colour = "grey40") +
  geom_point(size = 2, position = position_dodge(width = 0.5)) +
  facet_grid(panel ~ n_lab, scales = "free_y", labeller = label_parsed) +
  scale_colour_manual(values = c("#7570b3", "#e7298a", "black", "#d95f02"), name = NULL) +
  scale_shape_manual(values = c(15, 17, 16, 18), name = NULL) +
  labs(x = "True distribution", y = NULL) +
  theme_paper() +
  theme(legend.position = "bottom", axis.text.x = element_text(angle = 20, hjust = 1))
ggsave("figures/sim_prior.pdf", p3, width = fig_width, height = 8)

## ---------------------------------------------------------------------
## Figure 4: fitting error and WAIC, PC prior, all four fitted/true combinations
## (per replicate, skew-t truth)
## ---------------------------------------------------------------------
f4 <- subset(all, prior == "pc" & truth == "Skew-t")
f4$combo <- factor(paste0(ifelse(f4$dgp == "linear", "Linear", "Nonlinear"), " data\n",
                          ifelse(f4$fit == "parametric", "parametric fit", "semiparam. fit")),
                   levels = c("Linear data\nparametric fit", "Linear data\nsemiparam. fit",
                              "Nonlinear data\nparametric fit", "Nonlinear data\nsemiparam. fit"))
f4$Model <- ifelse(f4$fit == "parametric", "Parametric fit", "Semiparametric fit")
f4$Data  <- factor(ifelse(f4$dgp == "linear", "Linear data", "Nonlinear data"))
f4$n_lab <- factor(paste0("n = ", f4$n), levels = c("n = 50", "n = 200"))

box <- function(var, ylab) {
  ggplot(f4, aes(Data, .data[[var]], fill = Model)) +
    geom_boxplot(outlier.size = 0.4, linewidth = 0.3, position = position_dodge(width = 0.8)) +
    facet_wrap(~ n_lab, scales = "free_y") +
    scale_fill_manual(values = c("Parametric fit" = "grey80", "Semiparametric fit" = "#1b9e77"), name = NULL) +
    labs(x = NULL, y = ylab) +
    theme_paper() +
    theme(legend.position = "bottom")
}
p4 <- box("fit_error", "Absolute fitting error") / box("waic", "WAIC") +
  plot_layout(guides = "collect") & theme(legend.position = "bottom")
ggsave("figures/sim_model.pdf", p4, width = fig_width, height = 6.8)

cat("\nSaved figures/sim_prior.pdf and figures/sim_model.pdf\n")
