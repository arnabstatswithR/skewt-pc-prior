## =====================================================================
## Section 7.3: MCMC convergence diagnostics for the proposed model on a
## random sample of cells (two chains per cell, same settings as the main run)
##
## Output (console): distribution across cells of the effective sample size
## (per chain, out of 1,000 retained draws) and of the potential scale reduction
## factor (R-hat) for tau = 1/a, lambda*, b, and the location in 1901 and 2025
## Run: Rscript scripts/14_application_convergence.R      Packages: coda, parallel
## =====================================================================

source("R/pc_prior_functions.R")
source("R/skewt_mcmc.R")
library(coda)
library(parallel)

n_cells <- 100
n_cores <- max(1, detectCores() - 1)
mcmc    <- list(n_iter = 20000, n_burn = 10000, thin = 10)
K       <- 12

grid  <- build_ls_grid()
dat   <- read.csv("data/jjas_long.csv")
years <- sort(unique(dat$year))
B     <- bspline_basis(years, K)
set.seed(2026)
cells <- sort(sample(unique(dat$cell), n_cells))

diag_cell <- function(cl) {
  y <- sqrt(dat$y[dat$cell == cl][order(dat$year[dat$cell == cl])])
  ch <- lapply(1:2, function(k) {
    f <- do.call(skewt_mcmc, c(list(y = y, B = B, prior = "pc", family = "st", grid = grid,
                                    beta_block = TRUE, verbose = FALSE, seed = 1000 * cl + k), mcmc))
    S <- f$samples
    mu <- S[, 1:K] %*% t(B[c(1, nrow(B)), ])
    mcmc(cbind(tau = 1 / S[, "a"], lambda_star = S[, "lambda_star"], b = S[, "b"],
               mu_1901 = mu[, 1], mu_2025 = mu[, 2]))
  })
  ml <- mcmc.list(ch)
  ess <- sapply(ch, effectiveSize)                          # parameters x chains
  c(cell = cl, setNames(apply(ess, 1, min), paste0("ess_", rownames(ess))),
    setNames(gelman.diag(ml, autoburnin = FALSE, multivariate = FALSE)$psrf[, 1],
             paste0("rhat_", colnames(ch[[1]]))))
}

res <- mclapply(cells, function(cl) tryCatch(diag_cell(cl), error = function(e) NULL),
                mc.cores = n_cores, mc.preschedule = FALSE)
res <- do.call(rbind, res[!vapply(res, is.null, logical(1))])
cat("Cells diagnosed:", nrow(res), "\n\nEffective sample size per chain (of 1,000 draws), minimum over the two chains:\n")
print(round(apply(res[, grep("^ess_", colnames(res))], 2, quantile, c(0, 0.05, 0.5)), 0))
cat("\nPotential scale reduction factor (R-hat):\n")
print(round(apply(res[, grep("^rhat_", colnames(res))], 2, quantile, c(0.5, 0.95, 1)), 3))
cat("\nShare of cells with all R-hat < 1.05:", round(mean(apply(res[, grep("^rhat_", colnames(res))] < 1.05, 1, all)), 3), "\n")
saveRDS(res, "results/app_convergence.rds")
