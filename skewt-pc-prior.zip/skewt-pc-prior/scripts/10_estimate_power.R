## =====================================================================
## Section 7.3: choice of the power transformation of the JJAS totals
##   (1) variance-mean relationship across cells: if sd ~ mean^k, the
##       variance-stabilizing power is 1 - k (about 0.49, i.e. square root)
##   (2) pooled Box-Cox profile likelihood (about 0.31) and cell-wise estimates
##       (median about 0.38), for comparison
## Input: data/jjas_long.csv. Output: console; figures/power_choice.pdf
## Run: Rscript scripts/10_estimate_power.R      Packages: MASS, splines
## =====================================================================

library(MASS); library(splines)
dir.create("figures", showWarnings = FALSE)
dat <- read.csv("data/jjas_long.csv")
X <- bs(1901:2025, df = 12, intercept = TRUE)
ys <- split(dat$y, dat$cell)

## (1) Variance-mean relationship of the detrended totals
mv <- t(sapply(ys, function(y) c(m = mean(y), s = sd(residuals(lm(y ~ X - 1))))))
mv <- mv[mv[, "m"] > 0 & mv[, "s"] > 0, ]
k <- coef(lm(log(mv[, "s"]) ~ log(mv[, "m"])))[2]
cat("Variance-mean slope k:", round(k, 3), "=> variance-stabilizing power 1 - k:", round(1 - k, 3), "\n")

## (2) Box-Cox: pooled profile log-likelihood and cell-wise estimates
lam  <- seq(-0.2, 1, by = 0.01)
prof <- rowSums(sapply(ys, function(y) boxcox(I(y + 1) ~ X - 1, lambda = lam, plotit = FALSE)$y))
cat("Pooled Box-Cox estimate:", lam[which.max(prof)], "\n")
cat("Relative profile log-likelihood at p = 0, 1/4, 1/3, 1/2, 1:",
    round(sapply(c(0, 0.25, 1/3, 0.5, 1), function(p) approx(lam, prof, p)$y - max(prof)), 1), "\n")
bc <- sapply(ys, function(y) {
  b <- boxcox(I(y + 1) ~ X - 1, lambda = seq(-0.5, 1.5, 0.02), plotit = FALSE); b$x[which.max(b$y)]
})
cat("Cell-wise Box-Cox estimates, quantiles:\n"); print(quantile(bc, c(0.1, 0.25, 0.5, 0.75, 0.9)))

pdf("figures/power_choice.pdf", width = 10, height = 3.6)
par(mfrow = c(1, 3), mar = c(4.2, 4.2, 2, 1))
plot(log(mv[, "m"]), log(mv[, "s"]), pch = ".", xlab = "log mean", ylab = "log SD (detrended)",
     main = "Variance-mean relationship"); abline(lm(log(mv[, "s"]) ~ log(mv[, "m"])), col = 2)
plot(lam, prof - max(prof), type = "l", xlab = "power", ylab = "relative profile log-likelihood",
     main = "Pooled Box-Cox"); abline(v = c(1/3, 0.5), lty = 2)
hist(bc, breaks = 40, main = "Cell-wise Box-Cox estimates", xlab = "power"); abline(v = c(0, 0.5, 1), lty = 2)
dev.off()
