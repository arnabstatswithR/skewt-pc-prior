## =====================================================================
## Section 4.2.3: PC prior hyperparameters from tail probability statements
##   Pr(a < U_a) = eps_a              -> theta_a (closed form)
##   Pr(|lambda*| > U_l) = eps_l      -> theta_l (root search; reference a = Inf)
## Base R only.
## =====================================================================

kld_t_norm <- function(a) {          # Theorem 4.1, a > 2
  0.5 * log(2 * pi * a / (a - 2)) + 0.5 -
    (a + 1) / 2 * (digamma((a + 1) / 2) - digamma(a / 2)) -
    (0.5 * log(a) + lbeta(a / 2, 0.5))
}
d_a <- function(a) sqrt(2 * kld_t_norm(a))

binary_entropy <- function(u) {
  u <- pmin(pmax(u, 1e-300), 1 - 1e-16)
  -u * log(u) - (1 - u) * log1p(-u)
}
kld_sn_norm <- function(ls)          # Theorem 4.2 with a = Inf (skew-normal)
  integrate(function(z) 2 * dnorm(z) * (log(2) - binary_entropy(pnorm(ls * z))),
            0, Inf, rel.tol = 1e-10)$value
d_max <- sqrt(2 * log(2))

theta_a_from <- function(U_a, eps_a) -log(eps_a) / d_a(U_a)

theta_l_from <- function(U_l, eps_l) {
  dU <- sqrt(2 * kld_sn_norm(U_l))
  if (eps_l >= 1 - dU / d_max)
    stop("Not attainable: need eps_l < ", round(1 - dU / d_max, 3))
  f <- function(th) (exp(-th * dU) - exp(-th * d_max)) / (1 - exp(-th * d_max)) - eps_l
  uniroot(f, c(1e-8, 100), tol = 1e-10)$root
}

## Default:      Pr(a < 10) = 0.5, Pr(|lambda*| > 1) = 0.25 -> 5.10, 1.66
## Concentrated: Pr(a < 10) = 0.2, Pr(|lambda*| > 1) = 0.10 -> 11.83, 3.48
round(c(theta_a = theta_a_from(10, 0.5), theta_l = theta_l_from(1, 0.25)), 2)
round(c(theta_a = theta_a_from(10, 0.2), theta_l = theta_l_from(1, 0.10)), 2)
