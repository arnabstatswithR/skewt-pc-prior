## =====================================================================
## Semiparametric skew-t regression with the joint PC prior (Section 5)
##
## Model:  Y_i ~ ST(mu_i, lambda, a, b),  mu_i = B(x_i)' beta,
##         density (2):  f(y) = 2/s t_a(z) T_{a+1}(ls z sqrt((a+1)/(a+z^2))),
##         s = sqrt(b + lambda^2), z = (y - mu)/s, ls = lambda/sqrt(b).
## Priors: beta_k ~ N(0, 10^2), b ~ IG(0.01, 0.01),
##         a ~ PC(theta_a), lambda | a, b ~ PC(theta_l) on lambda*.
## Scale:  the response is standardized internally, y_std = (y - mean(y)) / sd(y),
##         so that the N(0, 10^2) prior on beta is weakly informative for any
##         units; results are transformed back (the basis sums to one, so
##         beta_orig = mean(y) + sd(y) * beta_std, lambda_orig = sd(y) * lambda_std,
##         b_orig = sd(y)^2 * b_std; a and lambda* are unchanged).
## MCMC:   adaptive random-walk Metropolis-Hastings within Gibbs on the
##         marginal likelihood; one parameter at a time (beta optionally
##         as a block); parameters on unconstrained scales:
##         beta_k, lambda, eta = log b, xi = log(a - 2).
##
## Requires: source("R/pc_prior_functions.R"); packages: splines (base R)
## =====================================================================

library(splines)

## ---------------------------------------------------------------------
## Cubic B-spline basis with K functions and equidistant knots
## (no separate intercept: the basis functions sum to one)
## ---------------------------------------------------------------------
bspline_basis <- function(x, K, range_x = range(x)) {
  interior <- seq(range_x[1], range_x[2], length.out = K - 2)[-c(1, K - 2)]
  bs(x, knots = interior, degree = 3, intercept = TRUE, Boundary.knots = range_x)
}

## ---------------------------------------------------------------------
## Skew-t log density, Eq. (2), vectorized in y and mu
## ---------------------------------------------------------------------
dst_log <- function(y, mu, lambda, a, b) {
  s  <- sqrt(b + lambda^2)
  ls <- lambda / sqrt(b)
  z  <- (y - mu) / s
  cf <- if (is.infinite(a)) 1 else sqrt((a + 1) / (a + z^2))     # a = Inf: skew-normal
  log(2) - log(s) + dt(z, df = a, log = TRUE) +
    pt(ls * z * cf, df = a + 1, log.p = TRUE)
}

## c_a such that E(Y) = mu + lambda * c_a (Section 2.1), a > 1
c_a <- function(a) ifelse(is.infinite(a), sqrt(2 / pi),
                          sqrt(a / pi) * exp(lgamma((a - 1) / 2) - lgamma(a / 2)))

## ---------------------------------------------------------------------
## Log prior (on the standardized scale)
## ---------------------------------------------------------------------
log_prior_all <- function(beta, lambda, a, b, hyper, grid) {
  sum(dnorm(beta, 0, hyper$sd_beta, log = TRUE)) +
    (-(hyper$b_shape + 1) * log(b) - hyper$b_rate / b) +        # IG(b_shape, b_rate)
    log_pc_a(a, hyper$theta_a) +
    log_prior_lambda(lambda, a, b, hyper$theta_l, grid)
}

## ---------------------------------------------------------------------
## Sampler
##   y: response; B: n x K basis matrix (or any design matrix)
##   prior = "pc" (proposed), "hrs" (Hazra et al. 2020:
##           lambda ~ N(0, 10^2), a ~ Uniform(0.1, 20)), or "js" (lambda ~ N(0, 10^2),
##           a ~ Gamma(2, 0.1); Juarez and Steel 2010)
##   family = "st" (skew-t), "t" (Student-t: lambda = 0 fixed) or
##            "sn" (skew-normal: a = Inf fixed); for "t" and "sn" with
##            prior = "pc", the PC prior of the free parameter is used
## ---------------------------------------------------------------------
skewt_mcmc <- function(y, B, n_iter = 25000, n_burn = 12500, thin = 5,
                       prior = c("pc", "hrs", "js"), family = c("st", "t", "sn"),
                       hyper = list(sd_beta = 10, b_shape = 0.01, b_rate = 0.01,
                                    theta_a = 5.10, theta_l = 1.66),
                       grid = NULL, beta_block = FALSE,
                       init = NULL, adapt_every = 100, seed = NULL,
                       verbose = TRUE) {
  prior <- match.arg(prior); family <- match.arg(family)
  if (family != "st" && prior != "pc") stop("family 't' and 'sn' are implemented with prior = 'pc'.")
  if (prior == "pc" && is.null(grid)) stop("Provide 'grid' from build_ls_grid().")
  if (!is.null(seed)) set.seed(seed)
  n <- length(y); K <- ncol(B)
  y_orig <- y; y_center <- mean(y); y_scale <- sd(y)
  y <- (y - y_center) / y_scale
  ## coefficient vector v with B v = 1 (constant function): v = (1, ..., 1) for a
  ## B-spline basis, v = (1, 0, ..., 0) for a design matrix with an intercept
  v_one <- as.numeric(qr.coef(qr(B), rep(1, n)))
  v_one[is.na(v_one)] <- 0
  if (max(abs(B %*% v_one - 1)) > 1e-8)
    stop("The column space of B must contain the constant function.")

  ## --- log prior under the chosen specification ---
  lprior <- function(beta, lambda, a, b) {
    if (family == "t")  return(sum(dnorm(beta, 0, hyper$sd_beta, log = TRUE)) +
                                 (-(hyper$b_shape + 1) * log(b) - hyper$b_rate / b) +
                                 log_pc_a(a, hyper$theta_a))
    if (family == "sn") return(sum(dnorm(beta, 0, hyper$sd_beta, log = TRUE)) +
                                 (-(hyper$b_shape + 1) * log(b) - hyper$b_rate / b) +
                                 log_prior_lambda(lambda, Inf, b, hyper$theta_l, grid))
    if (prior == "pc") return(log_prior_all(beta, lambda, a, b, hyper, grid))
    if (prior == "js") {                                         # Juarez and Steel (2010)
      return(sum(dnorm(beta, 0, hyper$sd_beta, log = TRUE)) +
               (-(hyper$b_shape + 1) * log(b) - hyper$b_rate / b) +
               dgamma(a, shape = 2, rate = 0.1, log = TRUE) +
               dnorm(lambda, 0, 10, log = TRUE))
    }
    if (a <= 0.1 || a >= 20) return(-Inf)
    sum(dnorm(beta, 0, hyper$sd_beta, log = TRUE)) +
      (-(hyper$b_shape + 1) * log(b) - hyper$b_rate / b) +
      dnorm(lambda, 0, 10, log = TRUE)                           # a ~ U(0.1, 20)
  }
  a_lower <- switch(prior, pc = 2, hrs = 0.1, js = 0)            # xi = log(a - a_lower)

  ## --- initial values: least squares for beta, lambda = 0, a = 10 ---
  if (is.null(init)) {
    beta   <- as.numeric(qr.solve(B, y))
    lambda <- 0
    a      <- if (family == "sn") Inf else 10
    b      <- as.numeric(var(as.numeric(y - B %*% beta))) * (if (family == "sn") 1 else (a - 2) / a)
  } else list2env(init, environment())

  mu     <- as.numeric(B %*% beta)
  loglik <- sum(dst_log(y, mu, lambda, a, b))
  lpost  <- loglik + lprior(beta, lambda, a, b)

  ## --- proposal scales and acceptance counters ---
  sd_beta <- rep(0.1 * sd(y), K); sd_lambda <- 0.5; sd_eta <- 0.2; sd_xi <- 0.5
  acc <- list(beta = numeric(K), lambda = 0, eta = 0, xi = 0)
  if (beta_block) {
    S_block  <- solve(crossprod(B)) * var(y)                    # initial block covariance
    sc_block <- 2.38^2 / K; acc_block <- 0
    L_block  <- t(chol(S_block))
  }

  keep  <- seq(n_burn + thin, n_iter, by = thin)
  keep_flag <- logical(n_iter); keep_flag[keep] <- TRUE
  out   <- matrix(NA_real_, length(keep), K + 3,
                  dimnames = list(NULL, c(paste0("beta", 1:K), "lambda", "a", "b")))
  ll_mat <- matrix(NA_real_, length(keep), n)                   # pointwise log-lik (WAIC)
  r <- 0

  tune <- function(sd, rate) if (rate < 0.3) sd * 0.8 else if (rate > 0.5) sd * 1.2 else sd

  for (it in 1:n_iter) {
    ## ----- beta -----
    if (!beta_block) {
      for (k in 1:K) {
        beta_p <- beta; beta_p[k] <- beta[k] + rnorm(1, 0, sd_beta[k])
        mu_p   <- mu + B[, k] * (beta_p[k] - beta[k])
        ll_p   <- sum(dst_log(y, mu_p, lambda, a, b))
        lp_p   <- ll_p + lprior(beta_p, lambda, a, b)
        if (log(runif(1)) < lp_p - lpost) {
          beta <- beta_p; mu <- mu_p; loglik <- ll_p; lpost <- lp_p
          acc$beta[k] <- acc$beta[k] + 1
        }
      }
    } else {
      beta_p <- beta + sqrt(sc_block) * as.numeric(L_block %*% rnorm(K))
      mu_p   <- as.numeric(B %*% beta_p)
      ll_p   <- sum(dst_log(y, mu_p, lambda, a, b))
      lp_p   <- ll_p + lprior(beta_p, lambda, a, b)
      if (log(runif(1)) < lp_p - lpost) {
        beta <- beta_p; mu <- mu_p; loglik <- ll_p; lpost <- lp_p
        acc_block <- acc_block + 1
      }
    }

    ## ----- lambda, with a mean-preserving shift of beta -----
    ## E(Y) = mu + lambda * c_a, and B v_one = 1, so shifting beta by
    ## -c_a * delta * v_one keeps the mean fixed while lambda changes by delta.
    ## (For a B-spline basis, v_one = (1, ..., 1): every beta_k is shifted.)
    ## The move (beta, lambda) -> (beta - c_a delta v_one, lambda + delta) is symmetric
    ## and volume preserving for fixed a, so the usual MH ratio applies.
    if (family != "t") {
    delta    <- rnorm(1, 0, sd_lambda)
    shift    <- if (a > 1) c_a(a) * delta else 0
    lambda_p <- lambda + delta
    beta_p   <- beta - shift * v_one          # B v_one = 1, so mu shifts by -shift
    mu_p     <- mu - shift
    ll_p <- sum(dst_log(y, mu_p, lambda_p, a, b))
    lp_p <- ll_p + lprior(beta_p, lambda_p, a, b)
    if (log(runif(1)) < lp_p - lpost) {
      lambda <- lambda_p; beta <- beta_p; mu <- mu_p
      loglik <- ll_p; lpost <- lp_p; acc$lambda <- acc$lambda + 1
    }
    }

    ## ----- eta = log b (Jacobian: + log b) -----
    b_p  <- exp(log(b) + rnorm(1, 0, sd_eta))
    ll_p <- sum(dst_log(y, mu, lambda, a, b_p))
    lp_p <- ll_p + lprior(beta, lambda, a, b_p)
    if (log(runif(1)) < (lp_p + log(b_p)) - (lpost + log(b))) {
      b <- b_p; loglik <- ll_p; lpost <- lp_p; acc$eta <- acc$eta + 1
    }

    ## ----- xi = log(a - a_lower) (Jacobian: + log(a - a_lower)) -----
    a_p  <- a_lower + exp(log(a - a_lower) + rnorm(1, 0, sd_xi))
    lpr  <- if (family == "sn") -Inf else lprior(beta, lambda, a_p, b)
    if (is.finite(lpr)) {
      ll_p <- sum(dst_log(y, mu, lambda, a_p, b))
      lp_p <- ll_p + lpr
      if (log(runif(1)) < (lp_p + log(a_p - a_lower)) - (lpost + log(a - a_lower))) {
        a <- a_p; loglik <- ll_p; lpost <- lp_p; acc$xi <- acc$xi + 1
      }
    }

    ## ----- adaptation during burn-in -----
    if (it <= n_burn && it %% adapt_every == 0) {
      if (!beta_block) {
        sd_beta <- mapply(tune, sd_beta, acc$beta / adapt_every)
      } else {
        sc_block <- tune(sc_block, acc_block / adapt_every); acc_block <- 0
      }
      sd_lambda <- tune(sd_lambda, acc$lambda / adapt_every)
      sd_eta    <- tune(sd_eta,    acc$eta    / adapt_every)
      sd_xi     <- tune(sd_xi,     acc$xi     / adapt_every)
      acc <- list(beta = numeric(K), lambda = 0, eta = 0, xi = 0)
    }
    if (it == n_burn) {                                        # reset counters
      acc <- list(beta = numeric(K), lambda = 0, eta = 0, xi = 0)
      if (beta_block) acc_block <- 0
    }

    ## ----- store -----
    if (keep_flag[it]) {
      r <- r + 1
      out[r, ] <- c(beta, lambda, a, b)
      ll_mat[r, ] <- dst_log(y, mu, lambda, a, b)
    }
    if (verbose && it %% 5000 == 0) cat("iteration", it, "\n")
  }

  n_post <- n_iter - n_burn
  rates <- c(beta = if (beta_block) acc_block / n_post else mean(acc$beta / n_post),
             lambda = acc$lambda / n_post, log_b = acc$eta / n_post,
             log_a = acc$xi / n_post)
  ## back to the original scale
  out[, 1:K]      <- sweep(y_scale * out[, 1:K, drop = FALSE], 2, y_center * v_one, "+")
  out[, "lambda"] <- y_scale * out[, "lambda"]
  out[, "b"]      <- y_scale^2 * out[, "b"]
  ll_mat <- ll_mat - log(y_scale)                 # pointwise log-lik on original scale
  samples <- cbind(out,
                   lambda_star = out[, "lambda"] / sqrt(out[, "b"]),
                   xi_gev      = 1 / out[, "a"])
  list(samples = samples, loglik = ll_mat, acceptance = rates, prior = prior, family = family)
}

## ---------------------------------------------------------------------
## WAIC and DIC
## ---------------------------------------------------------------------
waic <- function(ll) {
  m <- max(ll)
  lppd   <- sum(log(colMeans(exp(ll - m))) + m)
  p_waic <- sum(apply(ll, 2, var))
  c(WAIC = -2 * (lppd - p_waic), p_WAIC = p_waic)
}
dic <- function(fit, y, B) {
  K <- ncol(B); S <- fit$samples
  dev   <- -2 * rowSums(fit$loglik)
  beta  <- colMeans(S[, 1:K, drop = FALSE])
  dhat  <- -2 * sum(dst_log(y, as.numeric(B %*% beta), mean(S[, "lambda"]),
                            mean(S[, "a"]), mean(S[, "b"])))
  p_d <- mean(dev) - dhat
  c(DIC = mean(dev) + p_d, p_D = p_d)
}

## =====================================================================
## Demo: simulated data with a time covariate (run this block to test)
## =====================================================================
if (sys.nframe() == 0L) {
  source("R/pc_prior_functions.R")
  grid <- build_ls_grid()                                   # ~ minutes the first time
  print(check_interpolation(grid))                          # for Section 5 TODO

  set.seed(2026)
  n <- 125; t <- 1901:2025
  mu_true <- 60 + 8 * sin(2 * pi * (t - 1901) / 60)
  lambda <- 20; a <- 6; b <- 100                            # lambda* = 2
  sig <- sqrt(1 / rgamma(n, a / 2, a / 2))
  y <- mu_true + sig * abs(rnorm(n)) * lambda + sig * rnorm(n, 0, sqrt(b))

  B   <- bspline_basis(t, K = 12)
  fit <- skewt_mcmc(y, B, grid = grid, seed = 1)
  print(fit$acceptance)
  print(round(apply(fit$samples[, c("lambda", "a", "b", "lambda_star")], 2,
                    quantile, c(0.025, 0.5, 0.975)), 3))
  print(waic(fit$loglik)); print(dic(fit, y, B))
}
