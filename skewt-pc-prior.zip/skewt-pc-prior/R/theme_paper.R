## Common ggplot2 theme for all figures of the paper.
## Every figure is saved 7.5 inches wide and included at the full text width
## (about 5.15 inches), i.e., scaled by about 0.69. With base = 13, titles and
## axis titles appear at about 9 pt and tick and legend labels at about 7.5 pt
## in the paper, matching the caption size.
library(ggplot2)
for (d in c("figures", "results")) dir.create(d, showWarnings = FALSE)
fig_width <- 7.5
theme_paper <- function(base = 13) {
  theme_bw(base_size = base) +
    theme(plot.title   = element_text(size = base, hjust = 0.5),
          axis.title   = element_text(size = base),
          axis.text    = element_text(size = base - 2),
          legend.title = element_text(size = base - 1),
          legend.text  = element_text(size = base - 2),
          strip.text   = element_text(size = base - 1),
          plot.caption = element_text(size = base - 4, colour = "grey30"),
          legend.position = "bottom", legend.margin = margin(0, 0, 0, 0))
}
