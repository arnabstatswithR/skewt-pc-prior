## =====================================================================
## Joint PC prior for (a, lambda*) in the skew-t model (Section 4)
##
##   pi(a, lambda*) = pi_PC(a) * pi_PC(lambda* | a),   a > 2,
##   lambda* = lambda / sqrt(b).
##
## d(a) is in closed form (Theorem 4.1). d(lambda* | a) is a 1-D integral
## (Theorem 4.2); it is precomputed on a grid in (u = 1/a, lambda*) and
## interpolated: monotone cubic spline in lambda*, linear in u.
##
## Base R only. Source this file before skewt_mcmc.R.
## =====================================================================

## ---------------------------------------------------------------------
## Distance for the degrees of freedom (Theorem 4.1)
## For a > 500 the closed form loses precision (cancellation), so we use
## the expansion KLD(a) = 3/(4 a^2) + 3/(2 a^3) + O(a^-4).
## ---------------------------------------------------------------------
kld_a <- function(a) {
  out <- numeric(length(a))
  big <- a > 500
  ab  <- a[!big]
  out[!big] <- 0.5 * log(2 * pi * ab / (ab - 2)) + 0.5 -
    (ab + 1) / 2 * (digamma((ab + 1) / 2) - digamma(ab / 2)) -
    (0.5 * log(ab) + lbeta(ab / 2, 0.5))
  out[big] <- 0.75 / a[big]^2 + 1.5 / a[big]^3
  out
}
dkld_a <- function(a) {
  out <- numeric(length(a))
  big <- a > 500
  ab  <- a[!big]
  out[!big] <- (ab + 1) / 4 * (trigamma(ab / 2) - trigamma((ab + 1) / 2)) -
    1 / (2 * (ab - 2))
  out[big] <- -1.5 / a[big]^3 - 4.5 / a[big]^4
  out
}
d_a  <- function(a) sqrt(2 * kld_a(a))
dd_a <- function(a) dkld_a(a) / d_a(a)

log_pc_a <- function(a, theta_a) {
  ifelse(a <= 2, -Inf, log(theta_a) - theta_a * d_a(a) + log(abs(dd_a(a))))
}

## ---------------------------------------------------------------------
## Distance for the skewness given a (Theorem 4.2)
##   KLD(ls | a) = int_0^Inf 2 t_a(z) [log 2 - H{u_ls(z)}] dz
## ---------------------------------------------------------------------
d_max <- sqrt(2 * log(2))

binary_entropy <- function(u) {
  u <- pmin(pmax(u, 1e-300), 1 - 1e-16)
  -u * log(u) - (1 - u) * log1p(-u)
}

kld_ls_direct <- function(ls, a) {
  if (ls == 0) return(0)
  ls <- abs(ls)
  if (is.infinite(a)) {
    g <- function(z) 2 * dnorm(z) * (log(2) - binary_entropy(pnorm(ls * z)))
  } else {
    g <- function(z) 2 * dt(z, a) *
      (log(2) - binary_entropy(pt(ls * z * sqrt((a + 1) / (a + z^2)), a + 1)))
  }
  integrate(g, 0, Inf, rel.tol = 1e-10, subdivisions = 1000L)$value
}

## ---------------------------------------------------------------------
## Grid construction (run once; cached to an .rds file)
##   u = 1/a in [0, 1/2.05]  (u = 0 is the skew-normal, a = Inf)
##   lambda* in {0} U log-spaced (1e-3, ls_max)
## ---------------------------------------------------------------------
build_ls_grid <- function(n_u = 41, u_max = 1 / 2.05,
                          n_ls = 300, ls_max = 200,
                          cache = "R/cache_ls_grid.rds") {
  if (!is.null(cache) && file.exists(cache)) return(readRDS(cache))
  u_nodes  <- seq(0, u_max, length.out = n_u)
  ls_nodes <- c(0, exp(seq(log(1e-3), log(ls_max), length.out = n_ls)))
  D <- matrix(NA_real_, n_u, length(ls_nodes))
  for (j in seq_len(n_u)) {
    a <- if (u_nodes[j] == 0) Inf else 1 / u_nodes[j]
    D[j, ] <- sqrt(2 * sapply(ls_nodes, kld_ls_direct, a = a))
    cat(sprintf("grid row %d of %d done\n", j, n_u))
  }
  splines <- lapply(seq_len(n_u), function(j)
    splinefun(ls_nodes, D[j, ], method = "monoH.FC"))
  grid <- list(u = u_nodes, ls = ls_nodes, D = D, splines = splines,
               ls_max = ls_max)
  if (!is.null(cache)) saveRDS(grid, cache)
  grid
}

## Interpolated d(lambda* | a) (deriv = 0) or its derivative in |lambda*| (deriv = 1).
## Scalar a; vector ls allowed.
d_ls <- function(ls, a, grid, deriv = 0) {
  x <- pmin(abs(ls), grid$ls_max)          # beyond ls_max: distance ~ d_max, slope ~ 0
  u <- if (is.infinite(a)) 0 else 1 / a
  u <- min(max(u, 0), max(grid$u))
  j <- findInterval(u, grid$u, rightmost.closed = TRUE)
  j <- min(j, length(grid$u) - 1)
  w <- (u - grid$u[j]) / (grid$u[j + 1] - grid$u[j])
  out <- (1 - w) * grid$splines[[j]](x, deriv = deriv) +
         w       * grid$splines[[j + 1]](x, deriv = deriv)
  if (deriv == 1) out[abs(ls) > grid$ls_max] <- 0
  out
}

log_pc_ls <- function(ls, a, theta_l, grid) {
  d  <- d_ls(ls, a, grid)
  dp <- d_ls(ls, a, grid, deriv = 1)
  log(theta_l) - theta_l * d - log(2 * (1 - exp(-theta_l * d_max))) + log(abs(dp))
}

## Prior for lambda given (a, b): lambda* = lambda / sqrt(b), Jacobian 1/sqrt(b)
log_prior_lambda <- function(lambda, a, b, theta_l, grid) {
  log_pc_ls(lambda / sqrt(b), a, theta_l, grid) - 0.5 * log(b)
}

## ---------------------------------------------------------------------
## Interpolation accuracy (Section 5): compare with direct integration
## at random off-grid points
## ---------------------------------------------------------------------
check_interpolation <- function(grid, n = 300, seed = 1, theta_l = 1.66) {
  set.seed(seed)
  a  <- 2.05 + rexp(n, rate = 1 / 10)            # mostly a in (2, 50)
  ls <- runif(n, 0.01, 20)
  d_int  <- mapply(function(l, aa) d_ls(l, aa, grid), ls, a)
  d_dir  <- mapply(function(l, aa) sqrt(2 * kld_ls_direct(l, aa)), ls, a)
  h <- 1e-4                                      # derivative by central differences
  dp_int <- mapply(function(l, aa) d_ls(l, aa, grid, deriv = 1), ls, a)
  dp_dir <- mapply(function(l, aa)
    (sqrt(2 * kld_ls_direct(l + h, aa)) - sqrt(2 * kld_ls_direct(l - h, aa))) / (2 * h),
    ls, a)
  err_d    <- abs(d_int - d_dir)
  err_logp <- abs(log(dp_int) - log(dp_dir))
  ## error in the log conditional prior: theta_l * |error in d| + |error in log d'|
  c(max_abs_err_d               = max(err_d),
    max_abs_err_log_derivative  = max(err_logp),
    max_abs_err_logprior_default = max(theta_l * err_d + err_logp))
}
