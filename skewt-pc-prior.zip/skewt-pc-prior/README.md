# skewt-pc-prior

R code for the paper

> Hazra, A. *A semiparametric skew-t regression model with a principled joint distance-based prior.* Submitted to *Stochastic Environmental Research and Risk Assessment*.

The paper proposes a joint penalized complexity (PC) prior for the degrees of freedom and the standardized skewness parameter of a semiparametric skew-t regression model. It studies the prior in a simulation study and applies the model to summer monsoon (June–September) rainfall totals over India, 1901–2025, at 0.25° resolution.

## Repository structure

```
R/          functions used by the scripts
scripts/    one script per table, figure, or analysis step, numbered in the order they are run
```

All scripts are run **from the repository root**, for example `Rscript scripts/05_simulation_run.R`. They create the folders `data/`, `results/`, and `figures/` as needed.

### Functions (`R/`)

| File | Contents |
|---|---|
| `pc_prior_functions.R` | Kullback–Leibler divergences and distances for the degrees of freedom and the standardized skewness (Theorems 4.1–4.2), the joint PC prior, and its grid interpolation |
| `pc_hyperparameters.R` | Hyperparameters from tail-probability statements (Section 4.2.3) |
| `skewt_mcmc.R` | Adaptive Metropolis-within-Gibbs sampler for semiparametric skew-t, Student-t, and skew-normal regression (Section 5), with WAIC and DIC |
| `theme_paper.R` | Common ggplot2 theme for the figures |

### Scripts (`scripts/`)

| Script | Paper | Output |
|---|---|---|
| `01_figure1_skewt_properties.R` | Figure 1 | `figures/st_properties.pdf` |
| `02_table1_kld.R` | Table 1 | console |
| `03_figure2_pc_priors.R` | Figure 2 | `figures/pc_priors.pdf` |
| `04_remark51_da_vs_marginal.R` | Remark 5.1 | console (effective sample sizes) |
| `05_simulation_run.R` | Section 6 | `results/sim/` (long run) |
| `06_simulation_summarize.R` | Table 3, Figures 3–4 | `results/sim_table_rows.tex`, `figures/sim_prior.pdf`, `figures/sim_model.pdf` |
| `07_data_download.R` | Section 7.1 | `data/imd_raw/` (125 yearly NetCDF files) |
| `08_data_jjas_totals.R` | Section 7.1 | `data/jjas_total.rds` |
| `09_data_long.R` | Section 7.1 | `data/jjas_long.csv` |
| `10_estimate_power.R` | Section 7.3 (square-root transformation) | console, `figures/power_choice.pdf` |
| `11_application_fit.R` | Sections 7.3–7.6 | `results/app/`, `results/app_results.csv` (long run) |
| `12_application_summarize.R` | Table 4, Figures 6–10 | `results/app_table_rows.tex`, `figures/jjas_map.pdf`, `figures/app_*.pdf` |
| `13_application_fdr.R` | Section 7.6 (Bayesian false discovery rate) | console |
| `14_application_convergence.R` | Section 7.3 (convergence diagnostics) | console |
| `15_application_example_cells.R` | Figure 5, Supplementary Figure S1 | `figures/app_cells_resid.pdf`, `figures/app_cells_series.pdf` |

**Sensitivity analysis for 1951–2025 (Section 7.1):** set `year_min <- 1951` in `11_application_fit.R` and run it again. The results are saved to `results/app_1951/` and `results/app_1951_results.csv`, and `13_application_fdr.R` uses them if present.

## Data

The analysis uses the daily gridded rainfall data at 0.25° × 0.25° resolution from the India Meteorological Department (IMD), Pune (Pai et al., 2014), available at <https://www.imdpune.gov.in/cmpg/Griddata/Rainfall_25_NetCDF.html>. The data are not redistributed here. `07_data_download.R` downloads the yearly files. If the automatic download fails, download the files for 1901–2025 by hand from the page above and place them in `data/imd_raw/`, with the year in each file name.

Pai, D. S., Sridhar, L., Rajeevan, M., Sreejith, O. P., Satbhai, N. S., and Mukhopadhyay, B. (2014). Development of a new high spatial resolution (0.25° × 0.25°) long period (1901–2010) daily gridded rainfall data set over India and its comparison with existing data sets over the region. *Mausam*, 65(1), 1–18.

## Requirements

R (≥ 4.2) and the packages `sn`, `coda`, `ncdf4`, `httr`, `MASS`, `ggplot2`, `patchwork`, and `scales`. `splines` and `parallel` come with R.

```r
install.packages(c("sn", "coda", "ncdf4", "httr", "ggplot2", "patchwork", "scales"))
```

**Maps.** The maps in Section 7 are drawn on a Google terrain basemap through `ggmap` and `mapproj`. This requires a Google Maps Static API key, stored as `GGMAP_GOOGLE_API_KEY=your_key` in `~/.Renviron`. Without a key, set `basemap <- "none"` at the top of `12_application_summarize.R` to draw the maps without a basemap.

**Parallel computing.** The long runs use `parallel::mclapply`, which runs in parallel on Linux and macOS. On Windows it runs on one core.

## Computing time

Indicative times on a 24-thread workstation:

| Step | Time |
|---|---|
| Simulation study (`05`) | several hours |
| Application, 1901–2025 (`11`): about 4,900 cells, six models per cell | about 6 hours |
| Sensitivity run, 1951–2025 (`11` with `year_min <- 1951`) | about 3–4 hours |
| All other scripts | seconds to minutes |

## License

MIT; see `LICENSE`.
